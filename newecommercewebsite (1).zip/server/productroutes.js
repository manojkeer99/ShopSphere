/**
 * routes/productRoutes.js
 */

const express = require("express");

const router = express.Router();

const {
    createProduct,
    getAllProducts,
    getProductById,
    updateProduct,
    deleteProduct,
    updateStock,
    getFeaturedProducts,
    getTrendingProducts,
    getBestSellerProducts,
    getProductsByCategory,
    getRelatedProducts,
    increaseProductViews,
    getLowStockProducts,
    getProductStatistics
} = require("../controllers/productController");


const {
    protect,
    admin
} = require("../middleware/authMiddleware");



/* =====================================================
   Public Routes
===================================================== */

// All Products
router.get(
    "/",
    getAllProducts
);


// Featured Products
router.get(
    "/featured",
    getFeaturedProducts
);


// Trending Products
router.get(
    "/trending",
    getTrendingProducts
);


// Best Sellers
router.get(
    "/best-sellers",
    getBestSellerProducts
);


// Category Products
router.get(
    "/category/:categoryId",
    getProductsByCategory
);


// Related Products
router.get(
    "/:id/related",
    getRelatedProducts
);


// Product Details
router.get(
    "/:id",
    increaseProductViews,
    getProductById
);



/* =====================================================
   Admin Routes
===================================================== */


// Create Product
router.post(
    "/admin/create",
    protect,
    admin,
    createProduct
);


// Update Product
router.put(
    "/admin/:id",
    protect,
    admin,
    updateProduct
);


// Delete Product
router.delete(
    "/admin/:id",
    protect,
    admin,
    deleteProduct
);


// Update Stock
router.put(
    "/admin/:id/stock",
    protect,
    admin,
    updateStock
);


// Low Stock Products
router.get(
    "/admin/low-stock",
    protect,
    admin,
    getLowStockProducts
);


// Product Statistics
router.get(
    "/admin/statistics",
    protect,
    admin,
    getProductStatistics
);


module.exports = router;
/**
 * routes/productRoutes.js
 */


import express from "express";


import {

    getProducts,

    getProductDetails,

    createProduct,

    updateProduct,

    deleteProduct

} from "../controllers/productController.js";



import protect from "../middleware/authMiddleware.js";


import admin from "../middleware/adminMiddleware.js";




const router = express.Router();





// Get all products

router.get(

    "/",

    getProducts

);





// Product details

router.get(

    "/:id",

    getProductDetails

);





// Create product (Admin)

router.post(

    "/",

    protect,

    admin,

    createProduct

);





// Update product (Admin)

router.put(

    "/:id",

    protect,

    admin,

    updateProduct

);





// Delete product (Admin)

router.delete(

    "/:id",

    protect,

    admin,

    deleteProduct

);





export default router;