/**
 * pages/admin/AdminUsers.jsx
 */

import {
    useEffect
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getUsers
} from "../../features/users/userSlice";


import {
    FaTrash
} from "react-icons/fa";


import "./AdminUsers.css";



function AdminUsers(){


    const dispatch = useDispatch();



    const {

        users,

        loading

    } = useSelector(

        state=>state.users

    );




    useEffect(()=>{


        dispatch(

            getUsers()

        );


    },[dispatch]);





    const deleteUser=(id)=>{


        console.log(

            "Delete user",

            id

        );


        /*
          Admin delete user API
          will connect here
        */

    };





    return (

        <div className="admin-users">


            <h1>

                Manage Users

            </h1>




            {
                loading &&

                <h3>

                    Loading Users...

                </h3>

            }




            <table>


                <thead>


                    <tr>


                        <th>
                            Name
                        </th>


                        <th>
                            Email
                        </th>


                        <th>
                            Role
                        </th>


                        <th>
                            Action
                        </th>


                    </tr>


                </thead>



                <tbody>


                {

                users?.map(

                    user=>(


                    <tr

                    key={
                        user._id
                    }

                    >


                        <td>

                        {
                            user.name
                        }

                        </td>



                        <td>

                        {
                            user.email
                        }

                        </td>



                        <td>

                        {
                            user.role
                        }

                        </td>



                        <td>


                            <button

                            onClick={()=>deleteUser(

                                user._id

                            )}

                            >

                                <FaTrash/>

                            </button>


                        </td>



                    </tr>


                    )

                )

                }


                </tbody>


            </table>



        </div>

    );

}


export default AdminUsers;