/**
 * pages/admin/AdminProducts.jsx
 */

import {
    useEffect
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getProducts
} from "../../features/products/productSlice";


import {
    Link
} from "react-router-dom";


import {
    FaEdit,
    FaTrash,
    FaPlus
} from "react-icons/fa";


import "./AdminProducts.css";



function AdminProducts(){


    const dispatch = useDispatch();



    const {

        products,

        loading

    } = useSelector(

        state=>state.products

    );



    useEffect(()=>{


        dispatch(

            getProducts()

        );


    },[dispatch]);




    const deleteProduct=(id)=>{


        console.log(

            "Delete product",

            id

        );


        /*
          Admin delete API
          will connect here
        */


    };




    return (

        <div className="admin-products">


            <div className="admin-title">


                <h1>

                    Manage Products

                </h1>



                <Link to="/admin/product/new">

                    <FaPlus/>

                    Add Product

                </Link>


            </div>




            {
                loading &&

                <h3>

                    Loading...

                </h3>

            }




            <table>


                <thead>


                    <tr>


                        <th>
                            Image
                        </th>


                        <th>
                            Name
                        </th>


                        <th>
                            Price
                        </th>


                        <th>
                            Stock
                        </th>


                        <th>
                            Action
                        </th>


                    </tr>


                </thead>




                <tbody>


                {
                    products.map(

                        product=>(


                        <tr

                        key={
                            product._id
                        }

                        >


                            <td>

                                <img

                                src={
                                    product.image
                                }

                                alt=""
                                />

                            </td>



                            <td>

                            {
                                product.name
                            }

                            </td>




                            <td>

                            ₹
                            {
                                product.price
                            }

                            </td>




                            <td>

                            {
                                product.stock
                            }

                            </td>




                            <td>


                                <Link

                                to={
                                `/admin/product/edit/${product._id}`
                                }

                                >

                                    <FaEdit/>

                                </Link>




                                <button

                                onClick={()=>deleteProduct(

                                    product._id

                                )}

                                >

                                    <FaTrash/>

                                </button>


                            </td>


                        </tr>


                        )

                    )

                }


                </tbody>


            </table>


        </div>

    );

}


export default AdminProducts;