/**
 * pages/admin/AdminDashboard.jsx
 */


import {
    Link
} from "react-router-dom";


import {

    FaBox,
    FaUsers,
    FaShoppingCart,
    FaChartLine

} from "react-icons/fa";


import "./AdminDashboard.css";



function AdminDashboard(){


    return (

        <div className="admin-dashboard">


            <h1>

                Admin Dashboard

            </h1>



            <div className="admin-cards">


                <Link to="/admin/products">

                    <FaBox/>

                    <h3>

                        Products

                    </h3>

                </Link>



                <Link to="/admin/orders">

                    <FaShoppingCart/>

                    <h3>

                        Orders

                    </h3>

                </Link>




                <Link to="/admin/users">

                    <FaUsers/>

                    <h3>

                        Users

                    </h3>

                </Link>




                <Link to="/admin/analytics">

                    <FaChartLine/>

                    <h3>

                        Analytics

                    </h3>

                </Link>



            </div>


        </div>

    );

}


export default AdminDashboard;