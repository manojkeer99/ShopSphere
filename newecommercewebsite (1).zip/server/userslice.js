/**
 * features/users/userSlice.js
 */

import {
    createSlice,
    createAsyncThunk
} from "@reduxjs/toolkit";


import api from "../../api/api";



/* =====================================================
   Get All Users (Admin)
===================================================== */

export const getUsers =
createAsyncThunk(

    "users/getAll",

    async(_, {rejectWithValue})=>{


        try{


            const response =
            await api.get(

                "/admin/users"

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




/* =====================================================
   Delete User (Admin)
===================================================== */

export const deleteUser =
createAsyncThunk(

    "users/delete",

    async(id,{rejectWithValue})=>{


        try{


            const response =
            await api.delete(

                `/admin/users/${id}`

            );


            return id;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




/* =====================================================
   Update Role
===================================================== */

export const updateUserRole =
createAsyncThunk(

    "users/updateRole",

    async(data,{rejectWithValue})=>{


        try{


            const response =
            await api.put(

                `/admin/users/${data.id}`,

                {

                    role:data.role

                }

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);





const initialState={


    users:[],


    loading:false,


    error:null


};





const userSlice =
createSlice({

    name:"users",


    initialState,


    reducers:{



    },



    extraReducers:(builder)=>{


        builder


        .addCase(

            getUsers.fulfilled,

            (state,action)=>{


                state.users =
                action.payload.users;


            }

        )



        .addCase(

            deleteUser.fulfilled,

            (state,action)=>{


                state.users =
                state.users.filter(

                    user=>

                    user._id !== action.payload

                );


            }

        )



        .addCase(

            updateUserRole.fulfilled,

            (state,action)=>{


                const updatedUser =
                action.payload.user;



                const index =
                state.users.findIndex(

                    user=>

                    user._id === updatedUser._id

                );



                if(index !== -1){

                    state.users[index] =
                    updatedUser;

                }


            }

        );


    }


});



export default userSlice.reducer;