/**
 * middleware/authMiddleware.js
 */

const jwt = require("jsonwebtoken");
const User = require("../models/User");
const asyncHandler = require("./asyncHandler");

/* ============================================
   Protect Routes (Login Required)
============================================ */

exports.protect = asyncHandler(async (req, res, next) => {

    let token;

    // Token from Authorization Header
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer")
    ) {
        token = req.headers.authorization.split(" ")[1];
    }

    // Token from Cookie
    if (!token && req.cookies.token) {
        token = req.cookies.token;
    }

    // No Token
    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Access denied. Please login."
        });
    }

    // Verify JWT
    const decoded = jwt.verify(
        token,
        process.env.JWT_SECRET
    );

    // Get User
    const user = await User.findById(decoded.id).select("-password");

    if (!user) {
        return res.status(401).json({
            success: false,
            message: "User not found."
        });
    }

    // Blocked Account
    if (user.isBlocked) {
        return res.status(403).json({
            success: false,
            message: "Your account has been blocked."
        });
    }

    req.user = user;

    next();
});

/* ============================================
   Admin Only
============================================ */

exports.admin = (req, res, next) => {

    if (req.user.role !== "admin") {

        return res.status(403).json({

            success: false,

            message: "Admin access required."

        });

    }

    next();

};

/* ============================================
   Multiple Roles
============================================ */

exports.authorize = (...roles) => {

    return (req, res, next) => {

        if (!roles.includes(req.user.role)) {

            return res.status(403).json({

                success: false,

                message: "Unauthorized."

            });

        }

        next();

    };

};

/* ============================================
   Optional Login
============================================ */

exports.optionalAuth = asyncHandler(async (req, res, next) => {

    let token;

    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer")
    ) {

        token = req.headers.authorization.split(" ")[1];

    }

    if (!token) {

        return next();

    }

    try {

        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET
        );

        const user = await User.findById(decoded.id);

        if (user) {

            req.user = user;

        }

    } catch (error) {

        // Ignore invalid token

    }

    next();

});
/**
 * middleware/authMiddleware.js
 */


import jwt from "jsonwebtoken";


import User from "../models/User.js";




const protect = async(req,res,next)=>{


    try{


        const token =

        req.headers.authorization?.split(" ")[1];




        if(!token){


            return res.status(401).json({

                message:"Not authorized"

            });


        }





        const decoded =

        jwt.verify(

            token,

            process.env.JWT_SECRET

        );





        req.user =

        await User.findById(

            decoded.id

        )

        .select("-password");





        next();



    }

    catch(error){


        res.status(401).json({

            message:"Invalid token"

        });


    }


};



export default protect;
/**
 * middleware/adminMiddleware.js
 */


const admin = (req,res,next)=>{


    if(

        req.user &&

        req.user.role === "admin"

    ){


        next();


    }

    else{


        res.status(403).json({

            message:"Admin access required"

        });


    }


};



export default admin;