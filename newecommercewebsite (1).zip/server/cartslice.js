/**
 * features/cart/cartSlice.js
 */

import {
    createSlice,
    createAsyncThunk
} from "@reduxjs/toolkit";


import api from "../../api/api";



/* =====================================================
   Get Cart
===================================================== */

export const getCart =
createAsyncThunk(

    "cart/get",

    async(_, {rejectWithValue})=>{

        try{

            const response =
            await api.get(
                "/cart"
            );


            return response.data;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



/* =====================================================
   Add To Cart
===================================================== */

export const addToCart =
createAsyncThunk(

    "cart/add",

    async(data,{rejectWithValue})=>{

        try{

            const response =
            await api.post(

                "/cart/add",

                data

            );


            return response.data;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



/* =====================================================
   Remove From Cart
===================================================== */

export const removeFromCart =
createAsyncThunk(

    "cart/remove",

    async(id,{rejectWithValue})=>{

        try{

            const response =
            await api.delete(

                `/cart/remove/${id}`

            );


            return response.data;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



const initialState={


    items:[],


    subtotal:0,


    grandTotal:0,


    loading:false,


    error:null


};



const cartSlice =
createSlice({

    name:"cart",


    initialState,


    reducers:{


        clearCart:(state)=>{


            state.items=[];

            state.subtotal=0;

            state.grandTotal=0;


        }


    },



    extraReducers:(builder)=>{


        builder


        .addCase(
            getCart.fulfilled,
            (state,action)=>{


                state.items =
                action.payload.cart.items;


                state.subtotal =
                action.payload.cart.subtotal;


                state.grandTotal =
                action.payload.cart.grandTotal;


            }

        )



        .addCase(
            addToCart.fulfilled,
            (state,action)=>{


                state.items =
                action.payload.cart.items;


            }

        )



        .addCase(
            removeFromCart.fulfilled,
            (state,action)=>{


                state.items =
                action.payload.cart.items;


            }

        );


    }


});



export const {

    clearCart

} = cartSlice.actions;



export default cartSlice.reducer;