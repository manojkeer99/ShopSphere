/**
 * pages/Wishlist.jsx
 */

import {
    useEffect
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getWishlist,
    removeWishlist
} from "../features/wishlist/wishlistSlice";


import {
    FaTrash,
    FaShoppingCart
} from "react-icons/fa";


import "./Wishlist.css";



function Wishlist(){


    const dispatch = useDispatch();



    const {

        items

    } = useSelector(

        state=>state.wishlist

    );




    useEffect(()=>{


        dispatch(
            getWishlist()
        );


    },[dispatch]);




    const removeItem=(id)=>{


        dispatch(

            removeWishlist(id)

        );


    };




    const addToCart=(id)=>{


        console.log(

            "Move to cart",

            id

        );


        /*
          Cart add action
          will connect here
        */


    };




    return (

        <div className="wishlist-page">


            <h1>

                My Wishlist ❤️

            </h1>



            {
                items.length===0

                ?

                <h3>

                    Wishlist is empty

                </h3>


                :


                <div className="wishlist-grid">


                {
                    items.map(

                        item=>(


                        <div

                        className="wishlist-card"

                        key={
                            item._id
                        }

                        >



                            <img

                            src={
                                item.image
                            }

                            alt={
                                item.name
                            }

                            />



                            <h3>

                            {
                                item.name
                            }

                            </h3>



                            <p>

                            ₹
                            {
                                item.price
                            }

                            </p>




                            <button

                            onClick={()=>addToCart(

                                item._id

                            )}

                            >

                                <FaShoppingCart/>

                                Add Cart

                            </button>




                            <button

                            onClick={()=>removeItem(

                                item._id

                            )}

                            >

                                <FaTrash/>

                                Remove

                            </button>



                        </div>


                        )

                    )

                }


                </div>

            }



        </div>

    );

}


export default Wishlist;