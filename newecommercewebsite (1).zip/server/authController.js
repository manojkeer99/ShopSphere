/**
 * controllers/authController.js
 */
const crypto = require("crypto");
const User = require("../models/User");
const asyncHandler = require("../middleware/asyncHandler");
const { sendToken } = require("../utils/generateToken");
const bcrypt = require("bcryptjs");

/* =====================================================
   Register User
===================================================== */

exports.register = asyncHandler(async (req, res) => {

    const {
        name,
        email,
        password,
        phone
    } = req.body;

    // Validation
    if (!name || !email || !password) {
        return res.status(400).json({
            success: false,
            message: "Name, Email and Password are required."
        });
    }

    // Check existing user
    const existingUser = await User.findOne({
        email: email.toLowerCase()
    });

    if (existingUser) {
        return res.status(400).json({
            success: false,
            message: "Email already registered."
        });
    }

    // Create user
    const user = await User.create({
        name,
        email: email.toLowerCase(),
        password,
        phone
    });

    sendToken(user, 201, res);
});

/* =====================================================
   Login User
===================================================== */

exports.login = asyncHandler(async (req, res) => {

    const {
        email,
        password
    } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: "Email and Password are required."
        });
    }

    const user = await User.findOne({
        email: email.toLowerCase()
    }).select("+password");

    if (!user) {
        return res.status(401).json({
            success: false,
            message: "Invalid email or password."
        });
    }

    if (user.isBlocked) {
        return res.status(403).json({
            success: false,
            message: "Your account has been blocked."
        });
    }

    const isMatched = await user.comparePassword(password);

    if (!isMatched) {
        return res.status(401).json({
            success: false,
            message: "Invalid email or password."
        });
    }

    user.lastLogin = new Date();
    await user.save();

    sendToken(user, 200, res);
});

/* =====================================================
   Logout User
===================================================== */

exports.logout = asyncHandler(async (req, res) => {

    res.cookie("token", "", {
        expires: new Date(Date.now()),
        httpOnly: true
    });

    res.status(200).json({
        success: true,
        message: "Logged out successfully."
    });

});/* =====================================================
   Get Logged-in User Profile
===================================================== */

exports.getMyProfile = asyncHandler(async (req, res) => {

    const user = await User.findById(req.user._id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: "User not found."
        });
    }

    res.status(200).json({
        success: true,
        user
    });

});

/* =====================================================
   Update Profile
===================================================== */

exports.updateProfile = asyncHandler(async (req, res) => {

    const { name, phone } = req.body;

    const user = await User.findById(req.user._id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: "User not found."
        });
    }

    if (name) user.name = name;
    if (phone) user.phone = phone;

    await user.save();

    res.status(200).json({
        success: true,
        message: "Profile updated successfully.",
        user
    });

});

/* =====================================================
   Change Password
===================================================== */

exports.changePassword = asyncHandler(async (req, res) => {

    const {
        oldPassword,
        newPassword
    } = req.body;

    if (!oldPassword || !newPassword) {
        return res.status(400).json({
            success: false,
            message: "Old and new passwords are required."
        });
    }

    const user = await User.findById(req.user._id)
        .select("+password");

    const isMatched =
        await user.comparePassword(oldPassword);

    if (!isMatched) {

        return res.status(400).json({
            success: false,
            message: "Old password is incorrect."
        });

    }

    user.password = newPassword;

    await user.save();

    res.status(200).json({
        success: true,
        message: "Password changed successfully."
    });

});
/* =====================================================
   Forgot Password
===================================================== */

exports.forgotPassword = asyncHandler(async (req, res) => {

    const { email } = req.body;

    if (!email) {
        return res.status(400).json({
            success: false,
            message: "Email is required."
        });
    }

    const user = await User.findOne({
        email: email.toLowerCase()
    });

    if (!user) {
        return res.status(404).json({
            success: false,
            message: "No user found with this email."
        });
    }

    const resetToken = user.getResetPasswordToken();

    await user.save({
        validateBeforeSave: false
    });

    // Email sending will be implemented later
    const resetUrl =
        `${process.env.CLIENT_URL}/reset-password/${resetToken}`;

    res.status(200).json({
        success: true,
        message: "Password reset token generated.",
        resetUrl
    });

});
/**
 * controllers/authController.js
 */


import User from "../models/User.js";


import bcrypt from "bcryptjs";


import jwt from "jsonwebtoken";





// Generate JWT Token

const generateToken = (id)=>{


    return jwt.sign(

        {

            id

        },

        process.env.JWT_SECRET,

        {

            expiresIn:"7d"

        }

    );


};





/*
    Register User
*/

export const registerUser = async(req,res)=>{


    try{


        const {

            name,

            email,

            password,

            phone

        } = req.body;




        const existingUser =

        await User.findOne({

            email

        });



        if(existingUser){


            return res.status(400).json({

                message:"User already exists"

            });


        }




        const hashedPassword =

        await bcrypt.hash(

            password,

            10

        );





        const user = await User.create({


            name,

            email,

            phone,

            password:hashedPassword


        });





        res.status(201).json({


            message:"Registration successful",


            user:{


                id:user._id,

                name:user.name,

                email:user.email,

                role:user.role


            },


            token:

            generateToken(user._id)


        });


    }

    catch(error){


        res.status(500).json({

            message:error.message

        });


    }


};







/*
    Login User
*/

export const loginUser = async(req,res)=>{


    try{


        const {

            email,

            password

        } = req.body;





        const user =

        await User.findOne({

            email

        });





        if(!user){


            return res.status(404).json({

                message:"User not found"

            });


        }





        const isMatch =

        await bcrypt.compare(

            password,

            user.password

        );





        if(!isMatch){


            return res.status(401).json({

                message:"Invalid password"

            });


        }





        res.json({


            user:{


                id:user._id,

                name:user.name,

                email:user.email,

                role:user.role


            },


            token:

            generateToken(user._id)


        });



    }

    catch(error){


        res.status(500).json({

            message:error.message

        });


    }


};





/*
    Get Profile
*/

export const getProfile = async(req,res)=>{


    try{


        const user =

        await User.findById(

            req.user.id

        )

        .select("-password");





        res.json({

            user

        });


    }

    catch(error){


        res.status(500).json({

            message:error.message

        });


    }


};