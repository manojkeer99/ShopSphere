/**
 * features/orders/orderSlice.js
 */

import {
    createSlice,
    createAsyncThunk
} from "@reduxjs/toolkit";


import api from "../../api/api";



/* =====================================================
   Create Order
===================================================== */

export const createOrder =
createAsyncThunk(

    "orders/create",

    async(data,{rejectWithValue})=>{


        try{


            const response =
            await api.post(

                "/orders/create",

                data

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




/* =====================================================
   Get My Orders
===================================================== */

export const getMyOrders =
createAsyncThunk(

    "orders/myOrders",

    async(_,{rejectWithValue})=>{


        try{


            const response =
            await api.get(

                "/orders/my-orders"

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




/* =====================================================
   Get Order Details
===================================================== */

export const getOrderDetails =
createAsyncThunk(

    "orders/details",

    async(id,{rejectWithValue})=>{


        try{


            const response =
            await api.get(

                `/orders/${id}`

            );


            return response.data.order;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




const initialState={


    orders:[],


    order:null,


    loading:false,


    error:null,


    success:false


};




const orderSlice =
createSlice({

    name:"orders",


    initialState,


    reducers:{


        clearOrder:(state)=>{


            state.order=null;


        }


    },



    extraReducers:(builder)=>{


        builder


        .addCase(

            createOrder.pending,

            (state)=>{


                state.loading=true;


            }

        )



        .addCase(

            createOrder.fulfilled,

            (state,action)=>{


                state.loading=false;


                state.order =
                action.payload.order;


                state.success=true;


            }

        )



        .addCase(

            createOrder.rejected,

            (state,action)=>{


                state.loading=false;


                state.error =
                action.payload;


            }

        )



        .addCase(

            getMyOrders.fulfilled,

            (state,action)=>{


                state.orders =
                action.payload.orders;


            }

        )



        .addCase(

            getOrderDetails.fulfilled,

            (state,action)=>{


                state.order =
                action.payload;


            }

        );


    }


});



export const {

    clearOrder

} =
orderSlice.actions;



export default orderSlice.reducer;