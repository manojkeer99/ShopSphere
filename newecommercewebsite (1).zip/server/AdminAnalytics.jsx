/**
 * pages/admin/AdminAnalytics.jsx
 */


import {
    useEffect
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getAnalytics
} from "../../features/admin/adminSlice";


import {
    FaUsers,
    FaShoppingCart,
    FaRupeeSign,
    FaBox
} from "react-icons/fa";


import "./AdminAnalytics.css";



function AdminAnalytics(){


    const dispatch = useDispatch();



    const {

        analytics,

        loading

    } = useSelector(

        state=>state.admin

    );




    useEffect(()=>{


        dispatch(

            getAnalytics()

        );


    },[dispatch]);





    if(loading){

        return (

            <h2>

                Loading Analytics...

            </h2>

        );

    }





    return (

        <div className="analytics-page">


            <h1>

                Business Analytics

            </h1>




            <div className="analytics-cards">



                <div className="analytics-card">


                    <FaUsers/>


                    <h3>

                        Total Users

                    </h3>


                    <p>

                    {
                        analytics?.users || 0
                    }

                    </p>


                </div>





                <div className="analytics-card">


                    <FaShoppingCart/>


                    <h3>

                        Total Orders

                    </h3>


                    <p>

                    {
                        analytics?.orders || 0
                    }

                    </p>


                </div>





                <div className="analytics-card">


                    <FaRupeeSign/>


                    <h3>

                        Total Revenue

                    </h3>


                    <p>

                    ₹
                    {
                        analytics?.revenue || 0
                    }

                    </p>


                </div>





                <div className="analytics-card">


                    <FaBox/>


                    <h3>

                        Products

                    </h3>


                    <p>

                    {
                        analytics?.products || 0
                    }

                    </p>


                </div>



            </div>


        </div>

    );

}


export default AdminAnalytics;