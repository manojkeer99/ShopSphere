/**
 * controllers/productController.js
 */
import cloudinary from "../config/cloudinary.js";
const Product = require("../models/Product");
const Category = require("../models/Category");
const APIFeatures = require("../utils/apiFeatures");
const asyncHandler = require("../middleware/asyncHandler");

/* =====================================================
   Create Product
===================================================== */

exports.createProduct = asyncHandler(async (req, res) => {

    const {
        name,
        description,
        brand,
        category,
        price,
        discountPrice,
        stock,
        sku
    } = req.body;

    // Validation
    if (
        !name ||
        !description ||
        !brand ||
        !category ||
        !price ||
        !sku
    ) {
        return res.status(400).json({
            success: false,
            message: "Please fill all required fields."
        });
    }

    // Check category
    const categoryExists = await Category.findById(category);

    if (!categoryExists) {
        return res.status(404).json({
            success: false,
            message: "Category not found."
        });
    }

    // Check SKU
    const existingProduct = await Product.findOne({ sku });

    if (existingProduct) {
        return res.status(400).json({
            success: false,
            message: "SKU already exists."
        });
    }

    const product = await Product.create({
        name,
        description,
        brand,
        category,
        price,
        discountPrice,
        stock,
        sku,
        createdBy: req.user._id
    });

    res.status(201).json({
        success: true,
        message: "Product created successfully.",
        product
    });

});

/* =====================================================
   Get All Products
===================================================== */

exports.getAllProducts = asyncHandler(async (req, res) => {

    const resultPerPage =
        Number(req.query.limit) || 10;

    const apiFeature = new APIFeatures(
        Product.find({
            status: "active",
            isDeleted: false
        }).populate("category"),
        req.query
    )
        .search()
        .filter()
        .sort()
        .paginate(resultPerPage);

    const products = await apiFeature.query;

    const totalProducts = await Product.countDocuments({
        status: "active",
        isDeleted: false
    });

    res.status(200).json({

        success: true,

        count: products.length,

        totalProducts,

        page: Number(req.query.page) || 1,

        resultPerPage,

        products

    });

});

/* =====================================================
   Get Product By ID
===================================================== */

exports.getProductById = asyncHandler(async (req, res) => {

    const product = await Product
        .findById(req.params.id)
        .populate("category");

    if (!product) {

        return res.status(404).json({

            success: false,

            message: "Product not found."

        });

    }

    res.status(200).json({

        success: true,

        product

    });

});
/* =====================================================
   Update Product
===================================================== */

exports.updateProduct = asyncHandler(async (req, res) => {

    const product = await Product.findById(req.params.id);

    if (!product) {
        return res.status(404).json({
            success: false,
            message: "Product not found."
        });
    }

    const {
        name,
        description,
        brand,
        category,
        price,
        discountPrice,
        stock,
        featured,
        trending,
        bestSeller,
        status
    } = req.body;

    // Validate category if updated
    if (category) {

        const categoryExists = await Category.findById(category);

        if (!categoryExists) {
            return res.status(404).json({
                success: false,
                message: "Category not found."
            });
        }

        product.category = category;
    }

    if (name) product.name = name;
    if (description) product.description = description;
    if (brand) product.brand = brand;
    if (price !== undefined) product.price = price;
    if (discountPrice !== undefined)
        product.discountPrice = discountPrice;
    if (stock !== undefined) product.stock = stock;
    if (featured !== undefined) product.featured = featured;
    if (trending !== undefined) product.trending = trending;
    if (bestSeller !== undefined) product.bestSeller = bestSeller;
    if (status) product.status = status;

    product.updatedBy = req.user._id;

    await product.save();

    res.status(200).json({
        success: true,
        message: "Product updated successfully.",
        product
    });

});

/* =====================================================
   Soft Delete Product
===================================================== */

exports.deleteProduct = asyncHandler(async (req, res) => {

    const product = await Product.findById(req.params.id);

    if (!product) {
        return res.status(404).json({
            success: false,
            message: "Product not found."
        });
    }

    product.isDeleted = true;
    product.status = "inactive";
    product.updatedBy = req.user._id;

    await product.save();

    res.status(200).json({
        success: true,
        message: "Product deleted successfully."
    });

});

/* =====================================================
   Update Product Stock
===================================================== */

exports.updateStock = asyncHandler(async (req, res) => {

    const { stock } = req.body;

    const product = await Product.findById(req.params.id);

    if (!product) {
        return res.status(404).json({
            success: false,
            message: "Product not found."
        });
    }

    product.stock = stock;

    await product.save();

    res.status(200).json({
        success: true,
        message: "Stock updated successfully.",
        stock: product.stock
    });

});
/* =====================================================
   Get Featured Products
===================================================== */

exports.getFeaturedProducts = asyncHandler(async (req, res) => {

    const products = await Product.find({
        featured: true,
        status: "active",
        isDeleted: false
    })
    .populate("category")
    .limit(12);

    res.status(200).json({
        success: true,
        count: products.length,
        products
    });

});


/* =====================================================
   Get Trending Products
===================================================== */

exports.getTrendingProducts = asyncHandler(async (req, res) => {

    const products = await Product.find({
        trending: true,
        status: "active",
        isDeleted: false
    })
    .populate("category")
    .limit(12);

    res.status(200).json({
        success: true,
        count: products.length,
        products
    });

});


/* =====================================================
   Get Best Seller Products
===================================================== */

exports.getBestSellerProducts = asyncHandler(async (req, res) => {

    const products = await Product.find({
        bestSeller: true,
        status: "active",
        isDeleted: false
    })
    .populate("category")
    .sort("-totalSold")
    .limit(12);


    res.status(200).json({

        success: true,

        count: products.length,

        products

    });

});
/* =====================================================
   Get Products By Category
===================================================== */

exports.getProductsByCategory = asyncHandler(async (req, res) => {

    const { categoryId } = req.params;


    const products = await Product.find({

        category: categoryId,

        status: "active",

        isDeleted: false

    })
    .populate("category");


    res.status(200).json({

        success: true,

        count: products.length,

        products

    });

});


/* =====================================================
   Get Related Products
===================================================== */

exports.getRelatedProducts = asyncHandler(async (req, res) => {

    const product = await Product.findById(
        req.params.id
    );


    if (!product) {

        return res.status(404).json({

            success: false,

            message: "Product not found."

        });

    }


    const relatedProducts = await Product.find({

        category: product.category,

        _id: {
            $ne: product._id
        },

        status: "active",

        isDeleted: false

    })
    .limit(8)
    .populate("category");


    res.status(200).json({

        success: true,

        count: relatedProducts.length,

        products: relatedProducts

    });

});


/* =====================================================
   Increase Product Views
===================================================== */

exports.increaseProductViews = asyncHandler(async (req, res) => {

    const product = await Product.findById(
        req.params.id
    );


    if (!product) {

        return res.status(404).json({

            success:false,

            message:"Product not found."

        });

    }


    product.totalViews += 1;


    await product.save();


    res.status(200).json({

        success:true,

        message:"View counted."

    });

});
/* =====================================================
   Get Low Stock Products (Admin)
===================================================== */

exports.getLowStockProducts = asyncHandler(async (req, res) => {

    const limit = Number(req.query.limit) || 10;


    const products = await Product.find({

        stock: {
            $lte: limit
        },

        isDeleted:false

    })
    .populate("category")
    .sort("stock");


    res.status(200).json({

        success:true,

        count:products.length,

        products

    });

});


/* =====================================================
   Product Statistics (Admin Dashboard)
===================================================== */

exports.getProductStatistics = asyncHandler(async (req,res)=>{


    const totalProducts =
        await Product.countDocuments({
            isDeleted:false
        });


    const activeProducts =
        await Product.countDocuments({
            status:"active",
            isDeleted:false
        });


    const outOfStock =
        await Product.countDocuments({

            stock:0,

            isDeleted:false

        });


    const featuredProducts =
        await Product.countDocuments({

            featured:true,

            isDeleted:false

        });


    const totalViews =
        await Product.aggregate([

            {
                $group:{
                    _id:null,
                    views:{
                        $sum:"$totalViews"
                    }
                }
            }

        ]);


    const totalSold =
        await Product.aggregate([

            {
                $group:{
                    _id:null,
                    sold:{
                        $sum:"$totalSold"
                    }
                }
            }

        ]);


    res.status(200).json({

        success:true,

        statistics:{

            totalProducts,

            activeProducts,

            outOfStock,

            featuredProducts,

            totalViews:
                totalViews[0]?.views || 0,

            totalSold:
                totalSold[0]?.sold || 0

        }

    });


});
