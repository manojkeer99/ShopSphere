/**
 * services/emailService.js
 */

const nodemailer = require("nodemailer");

/* ==========================================
   Email Transport
========================================== */

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: {
        user: process.env.SMTP_EMAIL,
        pass: process.env.SMTP_PASSWORD
    }
});

/* ==========================================
   Send Email
========================================== */

const sendEmail = async ({
    to,
    subject,
    html,
    text
}) => {

    const mailOptions = {
        from: `"ShopSphere" <${process.env.SMTP_EMAIL}>`,
        to,
        subject,
        text,
        html
    };

    await transporter.sendMail(mailOptions);
};

/* ==========================================
   Password Reset Email
========================================== */

const sendPasswordResetEmail = async (
    email,
    name,
    resetUrl
) => {

    const html = `
        <h2>Hello ${name},</h2>

        <p>You requested to reset your password.</p>

        <p>
            Click the button below:
        </p>

        <a href="${resetUrl}"
           style="
                background:#0d6efd;
                color:#fff;
                padding:12px 20px;
                text-decoration:none;
                border-radius:5px;">
            Reset Password
        </a>

        <p>This link expires in 15 minutes.</p>

        <p>If you didn't request this, please ignore this email.</p>
    `;

    await sendEmail({
        to: email,
        subject: "Password Reset Request",
        html,
        text: `Reset your password: ${resetUrl}`
    });
};

/* ==========================================
   Email Verification
========================================== */

const sendVerificationEmail = async (
    email,
    name,
    verifyUrl
) => {

    const html = `
        <h2>Welcome ${name}</h2>

        <p>Please verify your email address.</p>

        <a href="${verifyUrl}"
           style="
                background:#198754;
                color:white;
                padding:12px 20px;
                text-decoration:none;
                border-radius:5px;">
            Verify Email
        </a>
    `;

    await sendEmail({
        to: email,
        subject: "Verify Your Email",
        html,
        text: `Verify your email: ${verifyUrl}`
    });
};

module.exports = {
    sendEmail,
    sendPasswordResetEmail,
    sendVerificationEmail
};