/**
 * features/auth/authSlice.js
 */

import {
    createSlice,
    createAsyncThunk
} from "@reduxjs/toolkit";


import api from "../../api/api";



/* =====================================================
   Login User
===================================================== */

export const loginUser =
createAsyncThunk(

    "auth/login",

    async(data,{rejectWithValue})=>{

        try{

            const response =
            await api.post(
                "/auth/login",
                data
            );


            localStorage.setItem(

                "user",

                JSON.stringify(
                    response.data.user
                )

            );


            return response.data;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



/* =====================================================
   Register User
===================================================== */

export const registerUser =
createAsyncThunk(

    "auth/register",

    async(data,{rejectWithValue})=>{

        try{

            const response =
            await api.post(
                "/auth/register",
                data
            );


            return response.data;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



const user =
JSON.parse(

    localStorage.getItem("user")

) || null;



const initialState={


    user,


    loading:false,


    error:null,


    success:false


};



const authSlice =
createSlice({

    name:"auth",


    initialState,


    reducers:{


        logout:(state)=>{


            state.user=null;


            localStorage.removeItem(
                "user"
            );


        },


        clearError:(state)=>{

            state.error=null;

        }


    },



    extraReducers:(builder)=>{


        builder


        .addCase(
            loginUser.pending,
            (state)=>{

                state.loading=true;

            }
        )


        .addCase(
            loginUser.fulfilled,
            (state,action)=>{

                state.loading=false;

                state.user =
                action.payload.user;

                state.success=true;

            }
        )


        .addCase(
            loginUser.rejected,
            (state,action)=>{

                state.loading=false;

                state.error =
                action.payload;

            }
        )


        .addCase(
            registerUser.pending,
            (state)=>{

                state.loading=true;

            }
        )


        .addCase(
            registerUser.fulfilled,
            (state)=>{

                state.loading=false;

                state.success=true;

            }
        )


        .addCase(
            registerUser.rejected,
            (state,action)=>{

                state.loading=false;

                state.error =
                action.payload;

            }
        );


    }


});



export const {

    logout,

    clearError

} = authSlice.actions;



export default authSlice.reducer;