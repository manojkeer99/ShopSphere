/**
 * routes/paymentRoutes.js
 */

const express = require("express");

const router = express.Router();


const {

    createPaymentOrder,
    verifyPayment,
    paymentFailed

} = require("../controllers/paymentController");


const {

    protect

} = require("../middleware/authMiddleware");



/* =====================================================
   Payment Routes
===================================================== */


// Create Razorpay Order
router.post(

    "/create-order",

    protect,

    createPaymentOrder

);


// Verify Payment
router.post(

    "/verify",

    protect,

    verifyPayment

);


// Payment Failed
router.post(

    "/failed",

    protect,

    paymentFailed

);



module.exports = router;