/**
 * pages/Products.jsx
 */

import {
    useEffect,
    useState
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getProducts
} from "../features/products/productSlice";


import ProductCard from "../components/ProductCard/ProductCard";


import "./Products.css";



function Products(){


    const dispatch = useDispatch();



    const {

        products,

        loading,

        error

    } = useSelector(

        state=>state.products

    );



    const [keyword,setKeyword]=useState("");



    useEffect(()=>{


        dispatch(
            getProducts()
        );


    },[dispatch]);



    const handleSearch=(e)=>{


        e.preventDefault();


        dispatch(

            getProducts({

                keyword

            })

        );


    };



    return (

        <div className="products-page">


            <h1>

                All Products

            </h1>



            <form

            className="product-search"

            onSubmit={handleSearch}

            >


                <input

                type="text"

                placeholder="Search products..."

                value={keyword}

                onChange={
                    e=>setKeyword(
                        e.target.value
                    )
                }

                />


                <button>

                    Search

                </button>


            </form>



            {
                loading &&

                <h3>

                    Loading products...

                </h3>

            }



            {
                error &&

                <p>

                    {error}

                </p>

            }




            <div className="product-grid">


            {
                products?.map(

                    product=>(

                        <ProductCard

                        key={
                            product._id
                        }

                        product={
                            product
                        }

                        />

                    )

                )

            }


            </div>


        </div>

    );

}


export default Products;