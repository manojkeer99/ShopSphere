/**
 * features/admin/adminSlice.js
 */

import {
    createSlice,
    createAsyncThunk
} from "@reduxjs/toolkit";


import api from "../../api/api";



/* =====================================================
   Get Admin Analytics
===================================================== */

export const getAnalytics =
createAsyncThunk(

    "admin/analytics",

    async(_, {rejectWithValue})=>{


        try{


            const response =
            await api.get(

                "/admin/analytics"

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);





const initialState={


    analytics:{},


    loading:false,


    error:null


};





const adminSlice =
createSlice({

    name:"admin",


    initialState,


    reducers:{



    },



    extraReducers:(builder)=>{


        builder


        .addCase(

            getAnalytics.pending,

            (state)=>{


                state.loading=true;


            }

        )



        .addCase(

            getAnalytics.fulfilled,

            (state,action)=>{


                state.loading=false;


                state.analytics =
                action.payload.analytics;


            }

        )



        .addCase(

            getAnalytics.rejected,

            (state,action)=>{


                state.loading=false;


                state.error =
                action.payload;


            }

        );


    }


});



export default adminSlice.reducer;