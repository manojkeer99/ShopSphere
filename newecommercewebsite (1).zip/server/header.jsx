/**
 * components/Header/Header.jsx
 */

import {
    Link,
    useNavigate
} from "react-router-dom";


import {
    useSelector,
    useDispatch
} from "react-redux";


import {
    logout
} from "../../features/auth/authSlice";


import {
    FaShoppingCart,
    FaHeart,
    FaUser
} from "react-icons/fa";


import "./Header.css";



function Header(){


    const navigate = useNavigate();

    const dispatch = useDispatch();



    const {
        user
    } = useSelector(
        state=>state.auth
    );


    const {
        items
    } = useSelector(
        state=>state.cart
    );



    const cartCount =
        items?.length || 0;



    const handleLogout=()=>{

        dispatch(logout());

        navigate("/login");

    };



    return (

        <header className="header">


            <div className="logo">

                <Link to="/">

                    ShopSphere

                </Link>

            </div>



            <div className="search-box">


                <input

                type="text"

                placeholder="Search products..."

                />


                <button>

                    Search

                </button>


            </div>



            <nav>


                <Link to="/wishlist">

                    <FaHeart/>

                </Link>



                <Link to="/cart">

                    <FaShoppingCart/>

                    <span>

                        {cartCount}

                    </span>

                </Link>



                {
                    user ?

                    <div className="user-menu">


                        <FaUser/>

                        <span>

                            {user.name}

                        </span>


                        <button

                        onClick={handleLogout}

                        >

                            Logout

                        </button>


                    </div>


                    :

                    <Link to="/login">

                        Login

                    </Link>

                }



            </nav>


        </header>

    );

}


export default Header;