/**
 * pages/admin/AdminOrders.jsx
 */

import {
    useEffect,
    useState
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getMyOrders
} from "../../features/orders/orderSlice";


import "./AdminOrders.css";



function AdminOrders(){


    const dispatch = useDispatch();



    const {

        orders,

        loading

    } = useSelector(

        state=>state.orders

    );




    useEffect(()=>{


        dispatch(

            getMyOrders()

        );


    },[dispatch]);





    const updateStatus=(id,status)=>{


        console.log(

            "Update status",

            id,

            status

        );


        /*
          Admin update order API
          will connect here
        */


    };





    return (

        <div className="admin-orders">


            <h1>

                Manage Orders

            </h1>



            {
                loading &&

                <h3>

                    Loading Orders...

                </h3>

            }




            <table>


                <thead>


                    <tr>


                        <th>
                            Order ID
                        </th>


                        <th>
                            Customer
                        </th>


                        <th>
                            Amount
                        </th>


                        <th>
                            Payment
                        </th>


                        <th>
                            Status
                        </th>


                    </tr>


                </thead>



                <tbody>


                {

                orders.map(

                    order=>(


                    <tr

                    key={
                        order._id
                    }

                    >


                        <td>

                        {
                            order._id
                        }

                        </td>



                        <td>

                        {
                            order.user?.name
                        }

                        </td>



                        <td>

                        ₹
                        {
                            order.totalAmount
                        }

                        </td>




                        <td>

                        {
                            order.paymentStatus
                        }

                        </td>




                        <td>


                            <select

                            value={
                                order.orderStatus
                            }

                            onChange={
                                e=>
                                updateStatus(

                                    order._id,

                                    e.target.value

                                )
                            }

                            >


                                <option>
                                    placed
                                </option>


                                <option>
                                    confirmed
                                </option>


                                <option>
                                    processing
                                </option>


                                <option>
                                    shipped
                                </option>


                                <option>
                                    delivered
                                </option>


                                <option>
                                    cancelled
                                </option>


                            </select>


                        </td>



                    </tr>


                    )

                )

                }


                </tbody>


            </table>


        </div>

    );

}


export default AdminOrders;