/**
 * pages/Profile.jsx
 */

import {
    useSelector
} from "react-redux";


import {
    Link
} from "react-router-dom";


import {
    FaUser,
    FaShoppingBag
} from "react-icons/fa";


import "./Profile.css";



function Profile(){


    const {

        user

    } = useSelector(

        state=>state.auth

    );




    if(!user){

        return (

            <h2>

                Please login first

            </h2>

        );

    }




    return (

        <div className="profile-page">


            <div className="profile-card">


                <FaUser className="profile-icon"/>



                <h2>

                    {user.name}

                </h2>



                <p>

                    Email:

                    {user.email}

                </p>



                <p>

                    Phone:

                    {user.phone}

                </p>




                <div className="profile-links">


                    <Link to="/my-orders">

                        <FaShoppingBag/>

                        My Orders

                    </Link>



                </div>



            </div>


        </div>

    );

}


export default Profile;