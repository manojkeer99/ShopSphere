/**
 * models/Review.js
 */

const mongoose = require("mongoose");

/* ==========================
   Review Image Schema
========================== */

const reviewImageSchema = new mongoose.Schema(
{
    public_id: String,

    url: String
},
{
    _id:false
});

/* ==========================
   Admin Reply
========================== */

const adminReplySchema = new mongoose.Schema(
{

    message:{
        type:String,
        default:""
    },

    repliedBy:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User"
    },

    repliedAt:{
        type:Date,
        default:Date.now
    }

},
{
    _id:false
});

/* ==========================
   Review Schema
========================== */

const reviewSchema = new mongoose.Schema(
{

    product:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Product",
        required:true
    },

    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
    },

    rating:{
        type:Number,
        required:true,
        min:1,
        max:5
    },

    title:{
        type:String,
        trim:true,
        maxlength:120
    },

    comment:{
        type:String,
        required:true,
        maxlength:3000
    },

    images:[reviewImageSchema],

    verifiedPurchase:{
        type:Boolean,
        default:false
    },

    helpfulVotes:{
        type:Number,
        default:0
    },

    reportedCount:{
        type:Number,
        default:0
    },

    isApproved:{
        type:Boolean,
        default:true
    },

    isDeleted:{
        type:Boolean,
        default:false
    },

    adminReply:adminReplySchema

},
{
    timestamps:true
});

/* ==========================
   Indexes
========================== */

reviewSchema.index({
    product:1,
    user:1
});

reviewSchema.index({
    rating:1
});

/* ==========================
   Methods
========================== */

reviewSchema.methods.markHelpful=function(){

    this.helpfulVotes++;

    return this.save();

};

reviewSchema.methods.report=function(){

    this.reportedCount++;

    return this.save();

};

module.exports=mongoose.model(
    "Review",
    reviewSchema
);