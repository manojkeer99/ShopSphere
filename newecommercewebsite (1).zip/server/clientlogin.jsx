/**
 * pages/Login.jsx
 */

import { 
    useState 
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    loginUser
} from "../features/auth/authSlice";


import {
    Link,
    useNavigate
} from "react-router-dom";


import toast from "react-hot-toast";



function Login(){


    const dispatch = useDispatch();

    const navigate = useNavigate();



    const {
        loading,
        error,
        user
    } = useSelector(
        state=>state.auth
    );



    const [form,setForm]=useState({

        email:"",

        password:""

    });



    const handleChange=(e)=>{

        setForm({

            ...form,

            [e.target.name]:
            e.target.value

        });

    };



    const handleSubmit=(e)=>{

        e.preventDefault();



        dispatch(loginUser(form))
        .unwrap()

        .then(()=>{

            toast.success(
                "Login successful"
            );

            navigate("/");

        })

        .catch((err)=>{

            toast.error(
                err || "Login failed"
            );

        });

    };



    return (

        <div className="auth-page">


            <div className="auth-box">


                <h2>
                    Login
                </h2>



                <form 
                onSubmit={handleSubmit}
                >


                    <input

                    type="email"

                    name="email"

                    placeholder="Email"

                    value={form.email}

                    onChange={handleChange}

                    required

                    />



                    <input

                    type="password"

                    name="password"

                    placeholder="Password"

                    value={form.password}

                    onChange={handleChange}

                    required

                    />



                    <button
                    type="submit"
                    disabled={loading}
                    >

                    {
                        loading
                        ?
                        "Loading..."
                        :
                        "Login"
                    }

                    </button>


                </form>



                {
                    error &&
                    <p className="error">
                        {error}
                    </p>
                }



                <p>

                    Don't have an account?

                    <Link to="/register">

                        Register

                    </Link>

                </p>



            </div>


        </div>

    );

}


export default Login;