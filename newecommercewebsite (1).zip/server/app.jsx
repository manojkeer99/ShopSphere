/**
 * src/App.jsx
 */


import {

Routes,

Route

} from "react-router-dom";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminRoute from "./components/AdminRoute/AdminRoute";
import MyOrders from "./pages/MyOrders";
import Profile from "./pages/Profile";
import Home from "./pages/Home";

import Login from "./pages/Login";

import Register from "./pages/Register";

import Products from "./pages/Products";

import ProductDetails from "./pages/ProductDetails";

import Cart from "./pages/Cart";

import Checkout from "./pages/Checkout";

import AdminProducts from "./pages/admin/AdminProducts";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminAnalytics from "./pages/admin/AdminAnalytics";
import Header from "./components/Header/Header";

import Footer from "./components/Footer/Footer";



import Header from "./components/Header/Header";

import Footer from "./components/Footer/Footer";

import AdminRoute from "./components/AdminRoute/AdminRoute";



// Pages

import Home from "./pages/Home";

import Products from "./pages/Products";

import ProductDetails from "./pages/ProductDetails";

import Cart from "./pages/Cart";

import Checkout from "./pages/Checkout";

import Wishlist from "./pages/Wishlist";

import Profile from "./pages/Profile";

import MyOrders from "./pages/MyOrders";



// Admin Pages

import AdminDashboard from "./pages/admin/AdminDashboard";

import AdminProducts from "./pages/admin/AdminProducts";

import AdminOrders from "./pages/admin/AdminOrders";

import AdminUsers from "./pages/admin/AdminUsers";

import AdminAnalytics from "./pages/admin/AdminAnalytics";




function App(){


    return (

        <>


            <Header/>



            <Routes>


                {/* Customer Routes */}


                <Route

                path="/"

                element={<Home/>}

                />


                <Route

                path="/products"

                element={<Products/>}

                />


                <Route

                path="/product/:id"

                element={<ProductDetails/>}

                />


                <Route

                path="/cart"

                element={<Cart/>}

                />


                <Route

                path="/checkout"

                element={<Checkout/>}

                />


                <Route

                path="/wishlist"

                element={<Wishlist/>}

                />


                <Route

                path="/profile"

                element={<Profile/>}

                />


                <Route

                path="/my-orders"

                element={<MyOrders/>}

                />




                {/* Admin Routes */}


                <Route

                path="/admin"

                element={

                    <AdminRoute>

                        <AdminDashboard/>

                    </AdminRoute>

                }

                />



                <Route

                path="/admin/products"

                element={

                    <AdminRoute>

                        <AdminProducts/>

                    </AdminRoute>

                }

                />



                <Route

                path="/admin/orders"

                element={

                    <AdminRoute>

                        <AdminOrders/>

                    </AdminRoute>

                }

                />



                <Route

                path="/admin/users"

                element={

                    <AdminRoute>

                        <AdminUsers/>

                    </AdminRoute>

                }

                />



                <Route

                path="/admin/analytics"

                element={

                    <AdminRoute>

                        <AdminAnalytics/>

                    </AdminRoute>

                }

                />





            <Route

            path="/"

            element={<Home />}

            />
            <Route
path="/admin/analytics"
element={
<AdminRoute>
<AdminAnalytics/>
</AdminRoute>
}
/>
            
<Route
path="/admin/products"
element={
<AdminRoute>
<AdminProducts/>
</AdminRoute>
}
/>
<Route
path="/admin/orders"
element={
<AdminRoute>
<AdminOrders/>
</AdminRoute>
}
/>
<Route
path="/my-orders"
element={<MyOrders />}
/>
            <Route

            path="/login"

            element={<Login />}

            />
<Route
path="/admin"
element={
<AdminRoute>
<AdminDashboard/>
</AdminRoute>
}
/>
<Route
path="/profile"
element={<Profile />}
/>
            <Route

            path="/register"

            element={<Register />}

            />


            <Route

            path="/products"

            element={<Products />}

            />


            <Route

            path="/product/:id"

            element={<ProductDetails />}

            />


            <Route

            path="/cart"

            element={<Cart />}

            />


            <Route

            path="/checkout"

            element={<Checkout />}

            />


        </Routes>



        <Footer />


        </>

    );

}


export default App;