/**
 * middleware/errorHandler.js
 * Global Error Handler
 */

const errorHandler = (err, req, res, next) => {

    let error = { ...err };

    error.message = err.message;

    console.error(err);

    // Mongoose Invalid ObjectId
    if (err.name === "CastError") {
        error.message = `Resource not found. Invalid ID: ${err.value}`;
        error.statusCode = 404;
    }

    // Duplicate Key Error
    if (err.code === 11000) {
        const field = Object.keys(err.keyValue)[0];

        error.message = `${field} already exists`;
        error.statusCode = 400;
    }

    // Mongoose Validation Error
    if (err.name === "ValidationError") {

        const messages = Object.values(err.errors).map(
            (item) => item.message
        );

        error.message = messages.join(", ");
        error.statusCode = 400;
    }

    // JWT Invalid
    if (err.name === "JsonWebTokenError") {
        error.message = "Invalid authentication token";
        error.statusCode = 401;
    }

    // JWT Expired
    if (err.name === "TokenExpiredError") {
        error.message = "Authentication token has expired";
        error.statusCode = 401;
    }

    res.status(error.statusCode || 500).json({

        success: false,

        message:
            error.message || "Internal Server Error",

        stack:
            process.env.NODE_ENV === "development"
                ? err.stack
                : undefined
    });
};

module.exports = errorHandler;