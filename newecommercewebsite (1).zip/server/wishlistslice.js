/**
 * features/wishlist/wishlistSlice.js
 */

import {
    createSlice,
    createAsyncThunk
} from "@reduxjs/toolkit";


import api from "../../api/api";



/* =====================================================
   Get Wishlist
===================================================== */

export const getWishlist =
createAsyncThunk(

    "wishlist/get",

    async(_,{rejectWithValue})=>{


        try{


            const response =
            await api.get(

                "/wishlist"

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




/* =====================================================
   Add Wishlist
===================================================== */

export const addWishlist =
createAsyncThunk(

    "wishlist/add",

    async(productId,{rejectWithValue})=>{


        try{


            const response =
            await api.post(

                "/wishlist/add",

                {

                    productId

                }

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




/* =====================================================
   Remove Wishlist
===================================================== */

export const removeWishlist =
createAsyncThunk(

    "wishlist/remove",

    async(productId,{rejectWithValue})=>{


        try{


            const response =
            await api.delete(

                `/wishlist/remove/${productId}`

            );


            return response.data;



        }
        catch(error){


            return rejectWithValue(

                error.response.data.message

            );


        }


    }

);




const initialState={


    items:[],


    loading:false,


    error:null


};




const wishlistSlice =
createSlice({

    name:"wishlist",


    initialState,


    reducers:{


        clearWishlist:(state)=>{


            state.items=[];


        }


    },



    extraReducers:(builder)=>{


        builder


        .addCase(

            getWishlist.fulfilled,

            (state,action)=>{


                state.items =
                action.payload.wishlist;


            }

        )



        .addCase(

            addWishlist.fulfilled,

            (state,action)=>{


                state.items =
                action.payload.wishlist;


            }

        )



        .addCase(

            removeWishlist.fulfilled,

            (state,action)=>{


                state.items =
                action.payload.wishlist;


            }

        );


    }


});



export const {

    clearWishlist

} =
wishlistSlice.actions;



export default wishlistSlice.reducer;