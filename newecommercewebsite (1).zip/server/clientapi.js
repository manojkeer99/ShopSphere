/**
 * api/api.js
 */

import axios from "axios";


const api = axios.create({

    baseURL:
    import.meta.env.VITE_API_URL ||
    "http://localhost:5000/api",

    headers:{

        "Content-Type":
        "application/json"

    }

});



/*
   Add JWT Token Automatically
*/

api.interceptors.request.use(

    (config)=>{


        const user =
        JSON.parse(
            localStorage.getItem("user")
        );


        if(user?.token){

            config.headers.Authorization =
            `Bearer ${user.token}`;

        }


        return config;

    },


    (error)=>{

        return Promise.reject(error);

    }

);



/*
   Handle Unauthorized Response
*/

api.interceptors.response.use(

    response=>response,


    error=>{


        if(
            error.response?.status === 401
        ){

            localStorage.removeItem("user");

        }


        return Promise.reject(error);

    }

);



export default api;