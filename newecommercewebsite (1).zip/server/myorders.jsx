/**
 * pages/MyOrders.jsx
 */

import {
    useEffect
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getMyOrders
} from "../features/orders/orderSlice";


import {
    Link
} from "react-router-dom";


import "./MyOrders.css";



function MyOrders(){


    const dispatch = useDispatch();



    const {

        orders,

        loading

    } = useSelector(

        state=>state.orders

    );




    useEffect(()=>{


        dispatch(

            getMyOrders()

        );


    },[dispatch]);





    return (

        <div className="orders-page">


            <h1>

                My Orders

            </h1>



            {
                loading &&

                <h3>

                    Loading orders...

                </h3>

            }




            {
                orders.length===0

                ?

                <h3>

                    No orders found

                </h3>


                :


                <div className="orders-list">


                {
                    orders.map(

                        order=>(


                        <div

                        className="order-card"

                        key={
                            order._id
                        }

                        >


                            <h3>

                                Order ID:

                                {
                                    order._id
                                }

                            </h3>



                            <p>

                                Date:

                                {
                                    new Date(
                                        order.createdAt
                                    )
                                    .toLocaleDateString()
                                }

                            </p>



                            <p>

                                Amount:

                                ₹
                                {
                                    order.totalAmount
                                }

                            </p>



                            <p>

                                Status:

                                <b>

                                {
                                    order.orderStatus
                                }

                                </b>


                            </p>




                            <Link

                            to={`/orders/${order._id}`}

                            >

                                View Details

                            </Link>



                        </div>


                        )

                    )

                }


                </div>

            }



        </div>

    );

}


export default MyOrders;