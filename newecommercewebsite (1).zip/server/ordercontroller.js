/**
 * controllers/orderController.js
 */

const Order = require("../models/Order");
const Cart = require("../models/Cart");
const Product = require("../models/Product");

const asyncHandler = require("../middleware/asyncHandler");



/* =====================================================
   Create Order From Cart
===================================================== */

exports.createOrder = asyncHandler(async(req,res)=>{


    const {
        shippingAddress,
        paymentMethod
    } = req.body;



    const cart =
        await Cart.findOne({

            user:req.user._id

        })
        .populate("items.product");



    if(!cart || cart.items.length === 0){

        return res.status(400).json({

            success:false,

            message:"Cart is empty."

        });

    }



    const orderItems =
        cart.items.map(item=>({

            product:item.product._id,

            name:item.product.name,

            image:item.product.image,

            quantity:item.quantity,

            price:item.price,

            total:item.total

        }));



    const order =
        await Order.create({

            user:req.user._id,

            items:orderItems,

            shippingAddress,

            paymentMethod,

            subtotal:cart.subtotal,

            shippingCharge:cart.shippingCharge,

            discount:cart.discount,

            totalAmount:cart.grandTotal

        });



    // Reduce Product Stock

    for(const item of cart.items){


        await Product.findByIdAndUpdate(

            item.product._id,

            {

                $inc:{

                    stock:-item.quantity,

                    totalSold:item.quantity

                }

            }

        );

    }



    // Clear Cart

    cart.items=[];

    cart.subtotal=0;

    cart.discount=0;

    cart.grandTotal=0;

    cart.couponCode="";


    await cart.save();



    res.status(201).json({

        success:true,

        message:"Order created successfully.",

        order

    });


});



/* =====================================================
   Get My Orders
===================================================== */

exports.getMyOrders = asyncHandler(async(req,res)=>{


    const orders =
        await Order.find({

            user:req.user._id

        })
        .sort("-createdAt");



    res.status(200).json({

        success:true,

        count:orders.length,

        orders

    });


});/* =====================================================
   Get Single Order Details
===================================================== */

exports.getOrderDetails = asyncHandler(async(req,res)=>{


    const order =
        await Order.findById(
            req.params.id
        )
        .populate("user","name email");



    if(!order){

        return res.status(404).json({

            success:false,

            message:"Order not found."

        });

    }



    // User can only view own order
    if(
        order.user._id.toString()
        !== req.user._id.toString()
        &&
        req.user.role !== "admin"
    ){

        return res.status(403).json({

            success:false,

            message:"Not authorized."

        });

    }



    res.status(200).json({

        success:true,

        order

    });


});



/* =====================================================
   Cancel Order
===================================================== */

exports.cancelOrder =
asyncHandler(async(req,res)=>{


    const order =
        await Order.findById(
            req.params.id
        );



    if(!order){

        return res.status(404).json({

            success:false,

            message:"Order not found."

        });

    }



    if(
        order.user.toString()
        !== req.user._id.toString()
    ){

        return res.status(403).json({

            success:false,

            message:"Not authorized."

        });

    }



    if(
        order.orderStatus === "delivered"
    ){

        return res.status(400).json({

            success:false,

            message:"Delivered order cannot be cancelled."

        });

    }



    order.orderStatus="cancelled";


    await order.save();



    res.status(200).json({

        success:true,

        message:"Order cancelled successfully.",

        order

    });


});



/* =====================================================
   Admin Get All Orders
===================================================== */

exports.getAllOrders =
asyncHandler(async(req,res)=>{


    const orders =
        await Order.find()

        .populate(
            "user",
            "name email"
        )

        .sort("-createdAt");



    res.status(200).json({

        success:true,

        count:orders.length,

        orders

    });


});



/* =====================================================
   Update Order Status (Admin)
===================================================== */

exports.updateOrderStatus =
asyncHandler(async(req,res)=>{


    const {
        status
    } = req.body;



    const order =
        await Order.findById(
            req.params.id
        );



    if(!order){

        return res.status(404).json({

            success:false,

            message:"Order not found."

        });

    }



    order.orderStatus=status;



    if(status==="delivered"){

        order.deliveredAt=Date.now();

    }



    await order.save();



    res.status(200).json({

        success:true,

        message:"Order status updated.",

        order

    });


});
/* =====================================================
   Update Payment Status (Admin)
===================================================== */

exports.updatePaymentStatus =
asyncHandler(async(req,res)=>{


    const {
        paymentStatus,
        transactionId
    } = req.body;


    const order =
        await Order.findById(
            req.params.id
        );


    if(!order){

        return res.status(404).json({

            success:false,

            message:"Order not found."

        });

    }


    order.paymentStatus =
        paymentStatus;


    if(transactionId){

        order.transactionId =
            transactionId;

    }


    await order.save();



    res.status(200).json({

        success:true,

        message:"Payment status updated.",

        order

    });


});



/* =====================================================
   Order Statistics (Admin Dashboard)
===================================================== */

exports.getOrderStatistics =
asyncHandler(async(req,res)=>{


    const totalOrders =
        await Order.countDocuments();



    const deliveredOrders =
        await Order.countDocuments({

            orderStatus:"delivered"

        });



    const pendingOrders =
        await Order.countDocuments({

            orderStatus:"placed"

        });



    const revenue =
        await Order.aggregate([

            {
                $match:{

                    paymentStatus:"paid"

                }

            },

            {
                $group:{

                    _id:null,

                    total:{
                        $sum:"$totalAmount"
                    }

                }

            }

        ]);



    res.status(200).json({

        success:true,

        statistics:{

            totalOrders,

            deliveredOrders,

            pendingOrders,

            revenue:
            revenue[0]?.total || 0

        }

    });


});