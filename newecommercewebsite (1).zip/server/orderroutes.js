/**
 * routes/orderRoutes.js
 */

const express = require("express");

const router = express.Router();


const {

    createOrder,
    getMyOrders,
    getOrderDetails,
    cancelOrder,
    getAllOrders,
    updateOrderStatus,
    updatePaymentStatus,
    getOrderStatistics

} = require("../controllers/orderController");


const {

    protect,
    admin

} = require("../middleware/authMiddleware");



/* =====================================================
   Customer Routes
===================================================== */


// Create Order
router.post(
    "/create",
    protect,
    createOrder
);


// My Orders
router.get(
    "/my-orders",
    protect,
    getMyOrders
);


// Order Details
router.get(
    "/:id",
    protect,
    getOrderDetails
);


// Cancel Order
router.put(
    "/cancel/:id",
    protect,
    cancelOrder
);



/* =====================================================
   Admin Routes
===================================================== */


// All Orders
router.get(
    "/admin/all",
    protect,
    admin,
    getAllOrders
);


// Update Order Status
router.put(
    "/admin/status/:id",
    protect,
    admin,
    updateOrderStatus
);


// Update Payment Status
router.put(
    "/admin/payment/:id",
    protect,
    admin,
    updatePaymentStatus
);


// Order Statistics
router.get(
    "/admin/statistics",
    protect,
    admin,
    getOrderStatistics
);



module.exports = router;