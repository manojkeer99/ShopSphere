/**
 * routes/wishlistRoutes.js
 */

const express = require("express");

const router = express.Router();


const {

    getMyWishlist,
    addToWishlist,
    removeFromWishlist,
    checkWishlistStatus,
    moveToCart,
    clearWishlist

} = require("../controllers/wishlistController");


const {
    protect

} = require("../middleware/authMiddleware");



/* =====================================================
   Wishlist Routes
===================================================== */


// Get Wishlist
router.get(
    "/",
    protect,
    getMyWishlist
);


// Add Product
router.post(
    "/add",
    protect,
    addToWishlist
);


// Remove Product
router.delete(
    "/remove/:productId",
    protect,
    removeFromWishlist
);


// Check Status
router.get(
    "/check/:productId",
    protect,
    checkWishlistStatus
);


// Move To Cart
router.post(
    "/move-to-cart",
    protect,
    moveToCart
);


// Clear Wishlist
router.delete(
    "/clear",
    protect,
    clearWishlist
);



module.exports = router;
/**
 * routes/wishlistRoutes.js
 */


import express from "express";


import {

    getWishlist,

    addWishlist,

    removeWishlist

} from "../controllers/wishlistController.js";


import protect from "../middleware/authMiddleware.js";



const router = express.Router();





// Get Wishlist

router.get(

    "/",

    protect,

    getWishlist

);





// Add Product

router.post(

    "/add",

    protect,

    addWishlist

);





// Remove Product

router.delete(

    "/remove/:productId",

    protect,

    removeWishlist

);





export default router;