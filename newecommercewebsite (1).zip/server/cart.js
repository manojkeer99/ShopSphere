/**
 * models/Cart.js
 */

const mongoose = require("mongoose");


/* ==========================================
   Cart Item Schema
========================================== */

const cartItemSchema = new mongoose.Schema({

    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Product",
        required: true
    },

    quantity: {
        type: Number,
        default: 1,
        min: 1
    },

    price: {
        type: Number,
        required: true
    },

    total: {
        type: Number,
        required: true
    }

}, {
    _id:false
});



/* ==========================================
   Cart Schema
========================================== */

const cartSchema = new mongoose.Schema({

    user: {

        type: mongoose.Schema.Types.ObjectId,

        ref:"User",

        required:true,

        unique:true

    },


    items:[cartItemSchema],


    subtotal:{

        type:Number,

        default:0

    },


    discount:{

        type:Number,

        default:0

    },


    shippingCharge:{

        type:Number,

        default:0

    },


    grandTotal:{

        type:Number,

        default:0

    },


    couponCode:{

        type:String,

        default:""

    }


},{

    timestamps:true

});



/* ==========================================
   Calculate Cart Total
========================================== */

cartSchema.methods.calculateTotal=function(){


    this.subtotal =
        this.items.reduce(
            (sum,item)=>sum + item.total,
            0
        );


    this.grandTotal =
        this.subtotal +
        this.shippingCharge -
        this.discount;


    return this.grandTotal;

};



module.exports =
mongoose.model(
    "Cart",
    cartSchema
);
/**
 * models/Cart.js
 */


import mongoose from "mongoose";



const cartSchema = new mongoose.Schema(

{


    user:{

        type:mongoose.Schema.Types.ObjectId,

        ref:"User",

        required:true,

        unique:true

    },



    items:[

        {


            product:{

                type:mongoose.Schema.Types.ObjectId,

                ref:"Product",

                required:true

            },


            quantity:{

                type:Number,

                default:1

            },


            price:{

                type:Number,

                required:true

            }


        }

    ],



    subtotal:{

        type:Number,

        default:0

    },


    grandTotal:{

        type:Number,

        default:0

    }



},


{

    timestamps:true

}


);



const Cart = mongoose.model(

    "Cart",

    cartSchema

);



export default Cart;