/**
 * controllers/paymentController.js
 */

const crypto = require("crypto");

const razorpay = require("../config/payment");

const Order = require("../models/Order");

const asyncHandler = require("../middleware/asyncHandler");



/* =====================================================
   Create Razorpay Order
===================================================== */

exports.createPaymentOrder =
asyncHandler(async(req,res)=>{


    const {
        amount
    } = req.body;



    if(!amount){

        return res.status(400).json({

            success:false,

            message:"Amount is required."

        });

    }



    const options = {

        amount:
        Math.round(amount * 100),

        currency:"INR",

        receipt:
        `receipt_${Date.now()}`

    };



    const paymentOrder =
        await razorpay.orders.create(
            options
        );



    res.status(200).json({

        success:true,

        paymentOrder

    });


});



/* =====================================================
   Verify Payment
===================================================== */

exports.verifyPayment =
asyncHandler(async(req,res)=>{


    const {

        razorpay_order_id,

        razorpay_payment_id,

        razorpay_signature,

        orderId

    } = req.body;



    const body =
        razorpay_order_id +
        "|" +
        razorpay_payment_id;



    const expectedSignature =
        crypto
        .createHmac(
            "sha256",
            process.env.RAZORPAY_KEY_SECRET
        )
        .update(body.toString())
        .digest("hex");



    const isAuthentic =
        expectedSignature ===
        razorpay_signature;



    if(!isAuthentic){

        return res.status(400).json({

            success:false,

            message:"Payment verification failed."

        });

    }



    const order =
        await Order.findById(
            orderId
        );



    if(order){

        order.paymentStatus =
            "paid";


        order.transactionId =
            razorpay_payment_id;


        await order.save();

    }



    res.status(200).json({

        success:true,

        message:"Payment verified successfully."

    });


});



/* =====================================================
   Payment Failed
===================================================== */

exports.paymentFailed =
asyncHandler(async(req,res)=>{


    const {
        orderId
    } = req.body;



    const order =
        await Order.findById(orderId);



    if(order){

        order.paymentStatus =
            "failed";


        await order.save();

    }



    res.status(200).json({

        success:true,

        message:"Payment failed recorded."

    });


});