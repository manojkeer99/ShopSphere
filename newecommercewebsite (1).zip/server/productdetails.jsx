/**
 * pages/ProductDetails.jsx
 */

import {
    useEffect
} from "react";


import {
    useParams
} from "react-router-dom";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getProductDetails,
    clearProduct
} from "../features/products/productSlice";


import {
    FaShoppingCart,
    FaHeart,
    FaStar
} from "react-icons/fa";


import "./ProductDetails.css";



function ProductDetails(){


    const {

        id

    } = useParams();



    const dispatch = useDispatch();



    const {

        product,

        loading

    } = useSelector(

        state=>state.products

    );



    useEffect(()=>{


        dispatch(
            getProductDetails(id)
        );


        return ()=>{

            dispatch(
                clearProduct()
            );

        };


    },[dispatch,id]);




    const addToCart=()=>{


        console.log(

            "Add cart",

            product._id

        );


    };



    const addWishlist=()=>{


        console.log(

            "Add wishlist",

            product._id

        );


    };




    if(loading){

        return (

            <h2>
                Loading...
            </h2>

        );

    }



    if(!product){

        return (

            <h2>

                Product not found

            </h2>

        );

    }



    return (

        <div className="product-details">


            <div className="details-image">


                <img

                src={
                    product.image
                }

                alt={
                    product.name
                }

                />


            </div>




            <div className="details-info">


                <h1>

                    {product.name}

                </h1>



                <div className="rating">


                    <FaStar/>

                    <span>

                        {
                        product.rating || 0
                        }

                    </span>


                </div>



                <h2>

                    ₹
                    {
                    product.discountPrice ||
                    product.price
                    }

                </h2>



                <p>

                    {product.description}

                </p>



                <p>

                    Stock:

                    {
                    product.stock
                    }

                </p>




                <button

                onClick={addToCart}

                >

                    <FaShoppingCart/>

                    Add To Cart

                </button>



                <button

                onClick={addWishlist}

                >

                    <FaHeart/>

                    Wishlist

                </button>



            </div>


        </div>

    );

}


export default ProductDetails;