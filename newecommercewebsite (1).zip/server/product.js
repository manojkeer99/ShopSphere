const mongoose = require("mongoose");
const slugify = require("slugify");

/* ==========================================================
   Product Image Schema
========================================================== */

const imageSchema = new mongoose.Schema(
  {
    public_id: {
      type: String,
      required: true,
      trim: true,
    },

    url: {
      type: String,
      required: true,
      trim: true,
    },

    alt: {
      type: String,
      default: "",
      trim: true,
    },

    isPrimary: {
      type: Boolean,
      default: false,
    },
  },
  { _id: false }
);

/* ==========================================================
   Product Specification Schema
========================================================== */

const specificationSchema = new mongoose.Schema(
  {
    key: {
      type: String,
      required: true,
      trim: true,
    },

    value: {
      type: String,
      required: true,
      trim: true,
    },
  },
  { _id: false }
);

/* ==========================================================
   Product Variant Schema
========================================================== */

const variantSchema = new mongoose.Schema(
  {
    color: {
      type: String,
      default: "",
      trim: true,
    },

    size: {
      type: String,
      default: "",
      trim: true,
    },

    sku: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    price: {
      type: Number,
      required: true,
      min: 0,
    },

    stock: {
      type: Number,
      default: 0,
      min: 0,
    },

    images: [imageSchema],
  },
  { _id: false }
);

/* ==========================================================
   Shipping Information
========================================================== */

const shippingSchema = new mongoose.Schema(
  {
    weight: {
      type: Number,
      default: 0,
    },

    length: {
      type: Number,
      default: 0,
    },

    width: {
      type: Number,
      default: 0,
    },

    height: {
      type: Number,
      default: 0,
    },

    freeShipping: {
      type: Boolean,
      default: false,
    },
  },
  { _id: false }
);

/* ==========================================================
   SEO Schema
========================================================== */

const seoSchema = new mongoose.Schema(
  {
    metaTitle: String,
    metaDescription: String,
    keywords: [String],
  },
  { _id: false }
);

/* ==========================================================
   Product Schema
========================================================== */

const productSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 200,
    },

    slug: {
      type: String,
      unique: true,
      lowercase: true,
    },

    description: {
      type: String,
      required: true,
    },

    shortDescription: {
      type: String,
      maxlength: 500,
    },

    brand: {
      type: String,
      required: true,
      trim: true,
    },

    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
      required: true,
    },

    images: [imageSchema],

    variants: [variantSchema],

    specifications: [specificationSchema],

    shipping: shippingSchema,

    seo: seoSchema,

    sku: {
      type: String,
      unique: true,
      required: true,
    },

    price: {
      type: Number,
      required: true,
      min: 0,
    },

    discountPrice: {
      type: Number,
      default: 0,
    },

    stock: {
      type: Number,
      default: 0,
    },

    sold: {
      type: Number,
      default: 0,
    },

    averageRating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5,
    },

    totalReviews: {
      type: Number,
      default: 0,
    },

    featured: {
      type: Boolean,
      default: false,
    },

    trending: {
      type: Boolean,
      default: false,
    },

    bestSeller: {
      type: Boolean,
      default: false,
    },

    status: {
      type: String,
      enum: [
        "draft",
        "active",
        "inactive",
        "out_of_stock"
      ],
      default: "active",
    },

    tags: [String],    isPublished: {
      type: Boolean,
      default: true,
    },

    isDeleted: {
      type: Boolean,
      default: false,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    }

},
{
    timestamps: true
});

/* ==========================================================
   INDEXES
========================================================== */

productSchema.index({ name: "text", description: "text" });
productSchema.index({ slug: 1 });
productSchema.index({ category: 1 });
productSchema.index({ brand: 1 });
productSchema.index({ price: 1 });
productSchema.index({ averageRating: -1 });
productSchema.index({ featured: 1 });
productSchema.index({ trending: 1 });

/* ==========================================================
   VIRTUALS
========================================================== */

productSchema.virtual("finalPrice").get(function () {

    if (
        this.discountPrice &&
        this.discountPrice > 0 &&
        this.discountPrice < this.price
    ) {
        return this.discountPrice;
    }

    return this.price;
});

productSchema.virtual("discountPercentage").get(function () {

    if (
        !this.discountPrice ||
        this.discountPrice <= 0 ||
        this.discountPrice >= this.price
    ) {
        return 0;
    }

    return Math.round(
        ((this.price - this.discountPrice) / this.price) * 100
    );
});

/* ==========================================================
   PRE SAVE
========================================================== */

productSchema.pre("save", function (next) {

    if (this.isModified("name")) {

        this.slug = slugify(this.name, {
            lower: true,
            strict: true
        });

    }

    next();

});

/* ==========================================================
   INSTANCE METHODS
========================================================== */

productSchema.methods.inStock = function () {

    return this.stock > 0;

};

productSchema.methods.reduceStock = async function (quantity) {

    if (quantity > this.stock) {

        throw new Error("Insufficient Stock");

    }

    this.stock -= quantity;

    this.sold += quantity;

    await this.save();

};

productSchema.methods.restoreStock = async function (quantity) {

    this.stock += quantity;

    if (this.sold >= quantity) {

        this.sold -= quantity;

    }

    await this.save();

};

productSchema.methods.calculateRating = function (reviews) {

    if (!reviews.length) {

        this.averageRating = 0;
        this.totalReviews = 0;

        return;
    }

    let total = 0;

    reviews.forEach(review => {

        total += review.rating;

    });

    this.totalReviews = reviews.length;

    this.averageRating = Number(
        (total / reviews.length).toFixed(1)
    );

};

/* ==========================================================
   STATIC METHODS
========================================================== */

productSchema.statics.getFeaturedProducts = function () {

    return this.find({
        featured: true,
        isDeleted: false,
        status: "active"
    });

};

productSchema.statics.getTrendingProducts = function () {

    return this.find({
        trending: true,
        isDeleted: false,
        status: "active"
    });

};

productSchema.statics.getBestSellers = function () {

    return this.find({
        bestSeller: true,
        isDeleted: false,
        status: "active"
    });

};

/* ==========================================================
   EXPORT
========================================================== */

module.exports = mongoose.model("Product", productSchema);
/* =====================================================
   Product Status
===================================================== */

status: {
    type: String,
    enum: [
        "active",
        "inactive",
        "draft",
        "out_of_stock"
    ],
    default: "active"
},

/* =====================================================
   Product Flags
===================================================== */

featured: {
    type: Boolean,
    default: false
},

trending: {
    type: Boolean,
    default: false
},

bestSeller: {
    type: Boolean,
    default: false
},

/* =====================================================
   Soft Delete
===================================================== */

isDeleted: {
    type: Boolean,
    default: false
},

/* =====================================================
   Product Statistics
===================================================== */

totalSold: {
    type: Number,
    default: 0
},

totalViews: {
    type: Number,
    default: 0
},

averageRating: {
    type: Number,
    default: 0
},

reviewCount: {
    type: Number,
    default: 0
},

/* =====================================================
   Created & Updated By
===================================================== */

createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
},

updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
}
productSchema.index({ featured: 1 });
productSchema.index({ trending: 1 });
productSchema.index({ bestSeller: 1 });
productSchema.index({ status: 1 });
productSchema.index({ category: 1 });
productSchema.index({ price: 1 });
/**
 * models/Product.js
 */


import mongoose from "mongoose";



const productSchema = new mongoose.Schema(

{


    name:{

        type:String,

        required:true

    },



    description:{

        type:String,

        required:true

    },



    price:{

        type:Number,

        required:true

    },



    discountPrice:{

        type:Number,

        default:0

    },



    image:{

        type:String,

        required:true

    },



    category:{

        type:String,

        required:true

    },



    brand:{

        type:String

    },



    stock:{

        type:Number,

        default:0

    },



    rating:{

        type:Number,

        default:0

    },



    reviews:[

        {

            user:{

                type:mongoose.Schema.Types.ObjectId,

                ref:"User"

            },


            comment:String,


            rating:Number

        }

    ],



    createdBy:{

        type:mongoose.Schema.Types.ObjectId,

        ref:"User"

    }



},


{

    timestamps:true

}


);



const Product = mongoose.model(

    "Product",

    productSchema

);



export default Product;