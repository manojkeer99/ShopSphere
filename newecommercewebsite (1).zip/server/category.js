/**
 * models/Category.js
 */

const mongoose = require("mongoose");
const slugify = require("slugify");

/* ===========================
   Image Schema
=========================== */

const imageSchema = new mongoose.Schema(
{
    public_id: {
        type: String,
        default: ""
    },

    url: {
        type: String,
        default: ""
    }
},
{
    _id: false
});

/* ===========================
   SEO Schema
=========================== */

const seoSchema = new mongoose.Schema(
{
    metaTitle: String,
    metaDescription: String,
    keywords: [String]
},
{
    _id: false
});

/* ===========================
   Category Schema
=========================== */

const categorySchema = new mongoose.Schema(
{

    name: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        maxlength: 100
    },

    slug: {
        type: String,
        unique: true
    },

    description: {
        type: String,
        default: ""
    },

    image: imageSchema,

    parentCategory: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Category",
        default: null
    },

    seo: seoSchema,

    featured: {
        type: Boolean,
        default: false
    },

    status: {
        type: String,
        enum: [
            "active",
            "inactive"
        ],
        default: "active"
    },

    displayOrder: {
        type: Number,
        default: 0
    },

    productCount: {
        type: Number,
        default: 0
    }

},
{
    timestamps: true
});

/* ===========================
   Indexes
=========================== */

categorySchema.index({
    name: 1
});

categorySchema.index({
    slug: 1
});

categorySchema.index({
    featured: 1
});

/* ===========================
   Generate Slug
=========================== */

categorySchema.pre("save", function(next){

    if(this.isModified("name")){

        this.slug = slugify(this.name,{
            lower:true,
            strict:true
        });

    }

    next();

});

/* ===========================
   Static Methods
=========================== */

categorySchema.statics.getFeatured = function(){

    return this.find({
        featured:true,
        status:"active"
    });

};

categorySchema.statics.getRootCategories = function(){

    return this.find({
        parentCategory:null,
        status:"active"
    });

};

/* ===========================
   Export
=========================== */

module.exports = mongoose.model(
    "Category",
    categorySchema
);