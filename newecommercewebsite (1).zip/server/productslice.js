/**
 * features/products/productSlice.js
 */

import {
    createSlice,
    createAsyncThunk
} from "@reduxjs/toolkit";


import api from "../../api/api";



/* =====================================================
   Get All Products
===================================================== */

export const getProducts =
createAsyncThunk(

    "products/getAll",

    async(params={}, {rejectWithValue})=>{

        try{

            const response =
            await api.get(
                "/products",
                {
                    params
                }
            );


            return response.data;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



/* =====================================================
   Get Featured Products
===================================================== */

export const getFeaturedProducts =
createAsyncThunk(

    "products/featured",

    async(_, {rejectWithValue})=>{

        try{

            const response =
            await api.get(
                "/products/featured"
            );


            return response.data;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



/* =====================================================
   Get Product Details
===================================================== */

export const getProductDetails =
createAsyncThunk(

    "products/details",

    async(id,{rejectWithValue})=>{

        try{

            const response =
            await api.get(
                `/products/${id}`
            );


            return response.data.product;


        }
        catch(error){

            return rejectWithValue(

                error.response.data.message

            );

        }

    }

);



const initialState={


    products:[],


    featuredProducts:[],


    product:null,


    loading:false,


    error:null


};



const productSlice =
createSlice({

    name:"products",


    initialState,


    reducers:{


        clearProduct:(state)=>{

            state.product=null;

        }


    },


    extraReducers:(builder)=>{


        builder


        // All Products

        .addCase(
            getProducts.pending,
            (state)=>{

                state.loading=true;

            }
        )


        .addCase(
            getProducts.fulfilled,
            (state,action)=>{

                state.loading=false;

                state.products =
                action.payload.products;

            }
        )


        .addCase(
            getProducts.rejected,
            (state,action)=>{

                state.loading=false;

                state.error =
                action.payload;

            }
        )



        // Featured

        .addCase(
            getFeaturedProducts.fulfilled,
            (state,action)=>{


                state.featuredProducts =
                action.payload.products;


            }
        )



        // Details

        .addCase(
            getProductDetails.fulfilled,
            (state,action)=>{


                state.product =
                action.payload;


            }
        );


    }


});



export const {

    clearProduct

} =
productSlice.actions;



export default productSlice.reducer;