/**
 * components/ProductCard/ProductCard.jsx
 */

import {
    Link
} from "react-router-dom";


import {
    useDispatch
} from "react-redux";


import {
    FaHeart,
    FaShoppingCart,
    FaStar
} from "react-icons/fa";


import "./ProductCard.css";



function ProductCard({product}){


    const dispatch = useDispatch();



    const addToCart=()=>{


        console.log(
            "Add to cart:",
            product._id
        );


        /*
          Cart Redux action
          will be connected here
        */

    };



    const addWishlist=()=>{


        console.log(

            "Add wishlist:",
            product._id

        );


        /*
          Wishlist Redux action
          will be connected here
        */

    };



    return (

        <div className="product-card">


            <div className="product-image">


                <Link
                to={`/product/${product._id}`}
                >

                    <img

                    src={
                        product.image ||
                        "/images/product.png"
                    }

                    alt={
                        product.name
                    }

                    />

                </Link>



                <button

                onClick={addWishlist}

                className="wishlist-btn"

                >

                    <FaHeart/>

                </button>


            </div>



            <div className="product-info">


                <h3>

                    {product.name}

                </h3>



                <div className="rating">


                    <FaStar/>


                    <span>

                        {product.rating || 0}

                    </span>


                </div>



                <div className="price">


                    {
                        product.discountPrice

                        ?

                        <>

                        <span className="old-price">

                            ₹{product.price}

                        </span>


                        <span>

                            ₹{product.discountPrice}

                        </span>

                        </>


                        :

                        <span>

                            ₹{product.price}

                        </span>

                    }


                </div>



                <button

                onClick={addToCart}

                className="cart-btn"

                >

                    <FaShoppingCart/>

                    Add To Cart

                </button>



            </div>


        </div>

    );

}


export default ProductCard;