/**
 * pages/Register.jsx
 */

import {
    useState
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    registerUser
} from "../features/auth/authSlice";


import {
    Link,
    useNavigate
} from "react-router-dom";


import toast from "react-hot-toast";



function Register(){


    const dispatch = useDispatch();

    const navigate = useNavigate();


    const {
        loading
    } = useSelector(
        state=>state.auth
    );



    const [form,setForm]=useState({

        name:"",

        email:"",

        phone:"",

        password:""

    });



    const handleChange=(e)=>{

        setForm({

            ...form,

            [e.target.name]:
            e.target.value

        });

    };



    const handleSubmit=(e)=>{

        e.preventDefault();


        dispatch(
            registerUser(form)
        )
        .unwrap()

        .then(()=>{


            toast.success(

                "Registration successful. Please login."

            );


            navigate("/login");


        })

        .catch((err)=>{


            toast.error(

                err || "Registration failed"

            );


        });


    };



    return (

        <div className="auth-page">


            <div className="auth-box">


                <h2>
                    Create Account
                </h2>



                <form
                onSubmit={handleSubmit}
                >


                    <input

                    type="text"

                    name="name"

                    placeholder="Full Name"

                    value={form.name}

                    onChange={handleChange}

                    required

                    />



                    <input

                    type="email"

                    name="email"

                    placeholder="Email"

                    value={form.email}

                    onChange={handleChange}

                    required

                    />



                    <input

                    type="tel"

                    name="phone"

                    placeholder="Phone Number"

                    value={form.phone}

                    onChange={handleChange}

                    />



                    <input

                    type="password"

                    name="password"

                    placeholder="Password"

                    value={form.password}

                    onChange={handleChange}

                    required

                    />



                    <button

                    type="submit"

                    disabled={loading}

                    >

                    {
                        loading
                        ?
                        "Creating..."
                        :
                        "Register"
                    }


                    </button>


                </form>



                <p>

                    Already have account?

                    <Link to="/login">

                        Login

                    </Link>


                </p>



            </div>


        </div>

    );

}


export default Register;