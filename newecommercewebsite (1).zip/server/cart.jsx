/**
 * pages/Cart.jsx
 */

import {
    useEffect
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getCart,
    removeFromCart
} from "../features/cart/cartSlice";


import {
    Link
} from "react-router-dom";


import {
    FaTrash
} from "react-icons/fa";


import "./Cart.css";



function Cart(){


    const dispatch = useDispatch();



    const {

        items,

        subtotal,

        grandTotal

    } = useSelector(

        state=>state.cart

    );




    useEffect(()=>{


        dispatch(
            getCart()
        );


    },[dispatch]);




    const removeItem=(id)=>{


        dispatch(

            removeFromCart(id)

        );


    };




    return (

        <div className="cart-page">


            <h1>

                Shopping Cart

            </h1>




            {
                items.length===0

                ?

                <h3>

                    Your cart is empty

                </h3>


                :

                <div className="cart-container">



                <div className="cart-items">



                {
                    items.map(

                        item=>(

                        <div

                        className="cart-item"

                        key={
                            item.product._id
                        }

                        >


                            <img

                            src={
                                item.product.image
                            }

                            alt={
                                item.product.name
                            }

                            />



                            <div>


                                <h3>

                                {
                                item.product.name
                                }

                                </h3>


                                <p>

                                Quantity:
                                {
                                item.quantity
                                }

                                </p>


                                <p>

                                ₹
                                {
                                item.total
                                }

                                </p>


                            </div>



                            <button

                            onClick={()=>removeItem(

                                item.product._id

                            )}

                            >

                                <FaTrash/>

                            </button>


                        </div>

                        )

                    )

                }


                </div>





                <div className="cart-summary">


                    <h2>

                        Cart Summary

                    </h2>



                    <p>

                        Subtotal:
                        ₹{subtotal}

                    </p>



                    <h3>

                        Total:
                        ₹{grandTotal}

                    </h3>



                    <Link to="/checkout">


                        <button>

                            Checkout

                        </button>


                    </Link>



                </div>




                </div>

            }


        </div>

    );

}


export default Cart;