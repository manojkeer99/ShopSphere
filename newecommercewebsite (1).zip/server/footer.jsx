/**
 * components/Footer/Footer.jsx
 */

import {
    Link
} from "react-router-dom";


import {
    FaFacebook,
    FaInstagram,
    FaTwitter,
    FaYoutube
} from "react-icons/fa";


import "./Footer.css";



function Footer(){


    return (

        <footer className="footer">


            <div className="footer-container">


                <div className="footer-section">


                    <h3>
                        ShopSphere
                    </h3>


                    <p>

                        Your trusted online shopping
                        destination.

                    </p>


                </div>



                <div className="footer-section">


                    <h3>
                        Quick Links
                    </h3>


                    <Link to="/">
                        Home
                    </Link>


                    <Link to="/products">
                        Products
                    </Link>


                    <Link to="/cart">
                        Cart
                    </Link>


                </div>



                <div className="footer-section">


                    <h3>
                        Customer Service
                    </h3>


                    <p>
                        Contact Us
                    </p>


                    <p>
                        Return Policy
                    </p>


                    <p>
                        Privacy Policy
                    </p>


                </div>



                <div className="footer-section">


                    <h3>
                        Follow Us
                    </h3>


                    <div className="social-icons">


                        <FaFacebook/>

                        <FaInstagram/>

                        <FaTwitter/>

                        <FaYoutube/>


                    </div>


                </div>


            </div>



            <div className="copyright">


                © 2026 ShopSphere. All Rights Reserved.


            </div>


        </footer>

    );

}


export default Footer;