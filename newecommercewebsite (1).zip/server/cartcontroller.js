/**
 * controllers/cartController.js
 */

const Cart = require("../models/Cart");
const Product = require("../models/Product");
const asyncHandler = require("../middleware/asyncHandler");



/* =====================================================
   Get My Cart
===================================================== */

exports.getMyCart = asyncHandler(async(req,res)=>{

    let cart = await Cart.findOne({
        user:req.user._id
    })
    .populate("items.product");


    if(!cart){

        cart = await Cart.create({

            user:req.user._id,

            items:[]

        });

    }


    res.status(200).json({

        success:true,

        cart

    });

});



/* =====================================================
   Add Product To Cart
===================================================== */

exports.addToCart = asyncHandler(async(req,res)=>{


    const {
        productId,
        quantity
    } = req.body;


    const product =
        await Product.findById(productId);



    if(!product){

        return res.status(404).json({

            success:false,

            message:"Product not found."

        });

    }



    if(product.stock < quantity){

        return res.status(400).json({

            success:false,

            message:"Insufficient stock."

        });

    }



    let cart =
        await Cart.findOne({

            user:req.user._id

        });



    if(!cart){

        cart =
        await Cart.create({

            user:req.user._id,

            items:[]

        });

    }



    const existingItem =
        cart.items.find(

            item =>
            item.product.toString()
            === productId

        );



    if(existingItem){


        existingItem.quantity += quantity;


        existingItem.total =
            existingItem.quantity *
            existingItem.price;


    }

    else{


        cart.items.push({

            product:productId,

            quantity,

            price:
            product.discountPrice ||
            product.price,

            total:
            quantity *
            (product.discountPrice ||
            product.price)

        });

    }



    cart.calculateTotal();


    await cart.save();



    res.status(200).json({

        success:true,

        message:"Product added to cart.",

        cart

    });


});



/* =====================================================
   Update Cart Quantity
===================================================== */

exports.updateCartQuantity =
asyncHandler(async(req,res)=>{


    const {
        productId,
        quantity
    } = req.body;



    const cart =
        await Cart.findOne({

            user:req.user._id

        });



    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }



    const item =
        cart.items.find(

            item =>
            item.product.toString()
            === productId

        );



    if(!item){

        return res.status(404).json({

            success:false,

            message:"Product not in cart."

        });

    }



    item.quantity = quantity;


    item.total =
        item.quantity *
        item.price;



    cart.calculateTotal();


    await cart.save();



    res.status(200).json({

        success:true,

        cart

    });


});
/* =====================================================
   Remove Product From Cart
===================================================== */

exports.removeFromCart = asyncHandler(async(req,res)=>{

    const { productId } = req.params;


    const cart =
        await Cart.findOne({
            user:req.user._id
        });


    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }


    cart.items =
        cart.items.filter(

            item =>
            item.product.toString()
            !== productId

        );


    cart.calculateTotal();


    await cart.save();


    res.status(200).json({

        success:true,

        message:"Product removed from cart.",

        cart

    });

});



/* =====================================================
   Clear Cart
===================================================== */

exports.clearCart = asyncHandler(async(req,res)=>{


    const cart =
        await Cart.findOne({

            user:req.user._id

        });


    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }


    cart.items=[];

    cart.discount=0;

    cart.couponCode="";

    cart.calculateTotal();


    await cart.save();


    res.status(200).json({

        success:true,

        message:"Cart cleared successfully."

    });


});



/* =====================================================
   Apply Coupon
===================================================== */

exports.applyCoupon = asyncHandler(async(req,res)=>{


    const {
        couponCode
    } = req.body;



    const cart =
        await Cart.findOne({

            user:req.user._id

        });



    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }



    /*
       Demo coupons

       Later we will connect
       Coupon Model
    */


    const coupons = {

        SAVE10:10,

        SAVE20:20

    };



    const discount =
        coupons[couponCode];



    if(!discount){

        return res.status(400).json({

            success:false,

            message:"Invalid coupon."

        });

    }



    cart.couponCode =
        couponCode;


    cart.discount =
        (cart.subtotal * discount) / 100;



    cart.calculateTotal();


    await cart.save();



    res.status(200).json({

        success:true,

        message:"Coupon applied.",

        cart

    });


});



/* =====================================================
   Remove Coupon
===================================================== */

exports.removeCoupon = asyncHandler(async(req,res)=>{


    const cart =
        await Cart.findOne({

            user:req.user._id

        });



    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }



    cart.couponCode="";

    cart.discount=0;


    cart.calculateTotal();


    await cart.save();



    res.status(200).json({

        success:true,

        message:"Coupon removed.",

        cart

    });


});
/* =====================================================
   Remove Item From Cart
===================================================== */

exports.removeFromCart = asyncHandler(async(req,res)=>{

    const { productId } = req.params;


    const cart = await Cart.findOne({
        user:req.user._id
    });


    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }


    cart.items =
        cart.items.filter(
            item =>
            item.product.toString() !== productId
        );


    cart.calculateTotal();


    await cart.save();


    res.status(200).json({

        success:true,

        message:"Product removed from cart.",

        cart

    });

});



/* =====================================================
   Clear Cart
===================================================== */

exports.clearCart = asyncHandler(async(req,res)=>{


    const cart = await Cart.findOne({

        user:req.user._id

    });


    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }


    cart.items = [];

    cart.discount = 0;

    cart.couponCode = "";


    cart.calculateTotal();


    await cart.save();


    res.status(200).json({

        success:true,

        message:"Cart cleared successfully.",

        cart

    });


});



/* =====================================================
   Apply Coupon
===================================================== */

exports.applyCoupon = asyncHandler(async(req,res)=>{


    const {
        couponCode
    } = req.body;


    const cart =
        await Cart.findOne({

            user:req.user._id

        });


    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }


    /*
       Demo Coupon Logic

       In production:
       Create Coupon model and validate
       from database.
    */


    if(couponCode === "WELCOME10"){

        cart.discount =
            cart.subtotal * 0.10;

        cart.couponCode =
            couponCode;

    }

    else{

        return res.status(400).json({

            success:false,

            message:"Invalid coupon."

        });

    }


    cart.calculateTotal();


    await cart.save();



    res.status(200).json({

        success:true,

        message:"Coupon applied.",

        cart

    });


});



/* =====================================================
   Remove Coupon
===================================================== */

exports.removeCoupon = asyncHandler(async(req,res)=>{


    const cart =
        await Cart.findOne({

            user:req.user._id

        });


    if(!cart){

        return res.status(404).json({

            success:false,

            message:"Cart not found."

        });

    }


    cart.discount = 0;

    cart.couponCode = "";


    cart.calculateTotal();


    await cart.save();


    res.status(200).json({

        success:true,

        message:"Coupon removed.",

        cart

    });


});