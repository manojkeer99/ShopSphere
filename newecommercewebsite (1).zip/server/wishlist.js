/**
 * models/Wishlist.js
 */

const mongoose = require("mongoose");


/* ==========================================
   Wishlist Schema
========================================== */

const wishlistSchema = new mongoose.Schema({

    user: {

        type: mongoose.Schema.Types.ObjectId,

        ref: "User",

        required: true,

        unique: true

    },


    products: [

        {

            type: mongoose.Schema.Types.ObjectId,

            ref: "Product"

        }

    ]

}, {

    timestamps: true

});



module.exports = mongoose.model(
    "Wishlist",
    wishlistSchema
);/**
 * models/Wishlist.js
 */


import mongoose from "mongoose";



const wishlistSchema = new mongoose.Schema(

{


    user:{

        type:mongoose.Schema.Types.ObjectId,

        ref:"User",

        required:true,

        unique:true

    },



    products:[

        {

            type:mongoose.Schema.Types.ObjectId,

            ref:"Product"

        }

    ]

},


{

    timestamps:true

}


);



const Wishlist = mongoose.model(

    "Wishlist",

    wishlistSchema

);



export default Wishlist;