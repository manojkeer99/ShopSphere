/**
 * store/store.js
 */


import {
    configureStore
} from "@reduxjs/toolkit";



import authReducer from "../features/auth/authSlice";


import productReducer from "../features/products/productSlice";


import cartReducer from "../features/cart/cartSlice";


import wishlistReducer from "../features/wishlist/wishlistSlice";


import orderReducer from "../features/orders/orderSlice";


import userReducer from "../features/users/userSlice";


import adminReducer from "../features/admin/adminSlice";




const store = configureStore({


    reducer:{


        auth:authReducer,


        products:productReducer,


        cart:cartReducer,


        wishlist:wishlistReducer,


        orders:orderReducer,


        users:userReducer,


        admin:adminReducer


    }


});



export default store;