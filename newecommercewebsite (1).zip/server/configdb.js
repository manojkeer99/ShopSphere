/**
 * config/db.js
 * MongoDB Connection
 */

const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    // Check if MongoDB URI exists
    if (!process.env.MONGO_URI) {
      console.error("❌ MONGO_URI is missing in .env file");
      process.exit(1);
    }

    // Connect to MongoDB
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      dbName: process.env.DB_NAME || "ecommerce",
      autoIndex: true,
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    });

    console.log("====================================");
    console.log("✅ MongoDB Connected Successfully");
    console.log(`Host     : ${conn.connection.host}`);
    console.log(`Database : ${conn.connection.name}`);
    console.log("====================================");

    // Connection Events
    mongoose.connection.on("connected", () => {
      console.log("MongoDB connection established.");
    });

    mongoose.connection.on("error", (err) => {
      console.error("MongoDB Error:", err.message);
    });

    mongoose.connection.on("disconnected", () => {
      console.warn("MongoDB disconnected.");
    });

  } catch (error) {
    console.error("❌ Database Connection Failed");
    console.error(error.message);
    process.exit(1);
  }
};

module.exports = connectDB;
/**
 * config/db.js
 */


import mongoose from "mongoose";



const connectDB = async()=>{


    try{


        await mongoose.connect(

            process.env.MONGO_URI

        );


        console.log(

            "MongoDB Connected"

        );


    }

    catch(error){


        console.log(

            error.message

        );


        process.exit(1);


    }


};



export default connectDB;