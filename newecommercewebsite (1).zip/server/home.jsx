/**
 * pages/Home.jsx
 */

import {
    Link
} from "react-router-dom";


import {
    useEffect
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    getFeaturedProducts
} from "../features/products/productSlice";


import ProductCard from "../components/ProductCard/ProductCard";


import "./Home.css";



function Home(){


    const dispatch = useDispatch();



    const {
        featuredProducts
    } = useSelector(
        state=>state.products
    );



    useEffect(()=>{

        dispatch(
            getFeaturedProducts()
        );

    },[dispatch]);



    return (

        <div className="home">


            {/* Hero Section */}

            <section className="hero">


                <div>

                    <h1>

                        Welcome to ShopSphere

                    </h1>


                    <p>

                        India's modern online shopping
                        experience

                    </p>


                    <Link to="/products">

                        <button>

                            Shop Now

                        </button>

                    </Link>


                </div>


            </section>




            {/* Categories */}

            <section className="categories">


                <h2>

                    Shop By Category

                </h2>


                <div className="category-box">


                    <div>
                        Electronics
                    </div>


                    <div>
                        Fashion
                    </div>


                    <div>
                        Home
                    </div>


                    <div>
                        Beauty
                    </div>


                </div>


            </section>




            {/* Featured Products */}

            <section className="featured">


                <h2>

                    Featured Products

                </h2>



                <div className="product-grid">


                    {
                        featuredProducts?.map(

                            product=>(

                                <ProductCard

                                key={
                                    product._id
                                }

                                product={
                                    product
                                }

                                />

                            )

                        )

                    }


                </div>


            </section>


        </div>

    );

}


export default Home;