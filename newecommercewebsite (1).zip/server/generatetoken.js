/**
 * utils/generateToken.js
 * JWT Token Utility
 */

const jwt = require("jsonwebtoken");

/**
 * Generate JWT Token
 * @param {String} userId
 * @param {String} role
 * @returns {String}
 */
const generateToken = (userId, role = "user") => {
    return jwt.sign(
        {
            id: userId,
            role: role
        },
        process.env.JWT_SECRET,
        {
            expiresIn: process.env.JWT_EXPIRE || "7d"
        }
    );
};

/**
 * Send JWT Token in Cookie + Response
 * @param {Object} user
 * @param {Number} statusCode
 * @param {Object} res
 */
const sendToken = (user, statusCode, res) => {

    const token = generateToken(user._id, user.role);

    const cookieOptions = {
        expires: new Date(
            Date.now() + 7 * 24 * 60 * 60 * 1000
        ),
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax"
    };

    res
        .status(statusCode)
        .cookie("token", token, cookieOptions)
        .json({
            success: true,
            token,
            user
        });
};

module.exports = {
    generateToken,
    sendToken
};