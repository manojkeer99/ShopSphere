/**
 * controllers/wishlistController.js
 */

const Wishlist = require("../models/Wishlist");
const Product = require("../models/Product");
const Cart = require("../models/Cart");

const asyncHandler = require("../middleware/asyncHandler");



/* =====================================================
   Get My Wishlist
===================================================== */

exports.getMyWishlist = asyncHandler(async(req,res)=>{


    let wishlist =
        await Wishlist.findOne({

            user:req.user._id

        })
        .populate("products");



    if(!wishlist){

        wishlist =
        await Wishlist.create({

            user:req.user._id,

            products:[]

        });

    }



    res.status(200).json({

        success:true,

        wishlist

    });


});



/* =====================================================
   Add Product To Wishlist
===================================================== */

exports.addToWishlist = asyncHandler(async(req,res)=>{


    const {
        productId
    } = req.body;



    const product =
        await Product.findById(productId);



    if(!product){

        return res.status(404).json({

            success:false,

            message:"Product not found."

        });

    }



    let wishlist =
        await Wishlist.findOne({

            user:req.user._id

        });



    if(!wishlist){

        wishlist =
        await Wishlist.create({

            user:req.user._id,

            products:[]

        });

    }



    const alreadyAdded =
        wishlist.products.includes(productId);



    if(alreadyAdded){

        return res.status(400).json({

            success:false,

            message:"Product already in wishlist."

        });

    }



    wishlist.products.push(productId);



    await wishlist.save();



    res.status(200).json({

        success:true,

        message:"Added to wishlist.",

        wishlist

    });


});



/* =====================================================
   Remove Product From Wishlist
===================================================== */

exports.removeFromWishlist =
asyncHandler(async(req,res)=>{


    const {
        productId
    } = req.params;



    const wishlist =
        await Wishlist.findOne({

            user:req.user._id

        });



    if(!wishlist){

        return res.status(404).json({

            success:false,

            message:"Wishlist not found."

        });

    }



    wishlist.products =
        wishlist.products.filter(

            id =>
            id.toString() !== productId

        );



    await wishlist.save();



    res.status(200).json({

        success:true,

        message:"Removed from wishlist.",

        wishlist

    });


});
/* =====================================================
   Check Wishlist Status
===================================================== */

exports.checkWishlistStatus =
asyncHandler(async(req,res)=>{


    const {
        productId
    } = req.params;



    const wishlist =
        await Wishlist.findOne({

            user:req.user._id

        });



    let exists = false;



    if(wishlist){

        exists =
        wishlist.products.some(

            id =>
            id.toString() === productId

        );

    }



    res.status(200).json({

        success:true,

        inWishlist:exists

    });


});



/* =====================================================
   Move Wishlist Item To Cart
===================================================== */

exports.moveToCart =
asyncHandler(async(req,res)=>{


    const {
        productId
    } = req.body;



    const product =
        await Product.findById(productId);



    if(!product){

        return res.status(404).json({

            success:false,

            message:"Product not found."

        });

    }



    // Add to Cart

    let cart =
        await Cart.findOne({

            user:req.user._id

        });



    if(!cart){

        cart =
        await Cart.create({

            user:req.user._id,

            items:[]

        });

    }



    const existingItem =
        cart.items.find(

            item =>
            item.product.toString()
            === productId

        );



    if(existingItem){

        existingItem.quantity += 1;

        existingItem.total =
            existingItem.quantity *
            existingItem.price;

    }

    else{

        const price =
            product.discountPrice ||
            product.price;


        cart.items.push({

            product:productId,

            quantity:1,

            price,

            total:price

        });

    }



    cart.calculateTotal();


    await cart.save();



    // Remove from wishlist

    const wishlist =
        await Wishlist.findOne({

            user:req.user._id

        });



    if(wishlist){

        wishlist.products =
        wishlist.products.filter(

            id =>
            id.toString() !== productId

        );


        await wishlist.save();

    }



    res.status(200).json({

        success:true,

        message:"Moved to cart successfully.",

        cart

    });


});



/* =====================================================
   Clear Wishlist
===================================================== */

exports.clearWishlist =
asyncHandler(async(req,res)=>{


    const wishlist =
        await Wishlist.findOne({

            user:req.user._id

        });



    if(!wishlist){

        return res.status(404).json({

            success:false,

            message:"Wishlist not found."

        });

    }



    wishlist.products = [];


    await wishlist.save();



    res.status(200).json({

        success:true,

        message:"Wishlist cleared."

    });


});
/**
 * controllers/wishlistController.js
 */


import Wishlist from "../models/Wishlist.js";





// Get Wishlist

export const getWishlist = async(req,res)=>{


    try{


        let wishlist = await Wishlist.findOne({

            user:req.user._id

        })

        .populate(

            "products"

        );





        if(!wishlist){


            wishlist = await Wishlist.create({

                user:req.user._id,

                products:[]

            });


        }




        res.json({

            wishlist

        });



    }

    catch(error){


        res.status(500).json({

            message:error.message

        });


    }


};







// Add Product To Wishlist

export const addWishlist = async(req,res)=>{


    try{


        const {

            productId

        } = req.body;




        let wishlist = await Wishlist.findOne({

            user:req.user._id

        });





        if(!wishlist){


            wishlist = new Wishlist({

                user:req.user._id,

                products:[]

            });


        }






        const exists =

        wishlist.products.includes(

            productId

        );





        if(!exists){


            wishlist.products.push(

                productId

            );


        }




        await wishlist.save();





        await wishlist.populate(

            "products"

        );





        res.json({

            wishlist

        });



    }

    catch(error){


        res.status(500).json({

            message:error.message

        });


    }


};







// Remove Product

export const removeWishlist = async(req,res)=>{


    try{


        const wishlist =

        await Wishlist.findOne({

            user:req.user._id

        });





        wishlist.products =

        wishlist.products.filter(

            product=>

            product.toString()

            !== req.params.productId

        );





        await wishlist.save();





        await wishlist.populate(

            "products"

        );





        res.json({

            wishlist

        });



    }

    catch(error){


        res.status(500).json({

            message:error.message

        });


    }


};