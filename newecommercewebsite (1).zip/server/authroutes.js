/**
 * routes/authRoutes.js
 */

const express = require("express");

const router = express.Router();

const {
    register,
    login,
    logout,
    getMyProfile,
    updateProfile,
    changePassword,
    forgotPassword,
    resetPassword
} = require("../controllers/authController");

const {
    protect
} = require("../middleware/authMiddleware");

/* =====================================================
   Public Routes
===================================================== */

// Register
router.post("/register", register);

// Login
router.post("/login", login);

// Logout
router.get("/logout", logout);

// Forgot Password
router.post("/forgot-password", forgotPassword);

// Reset Password
router.put("/reset-password/:token", resetPassword);

/* =====================================================
   Protected Routes
===================================================== */

// Get Logged-in User
router.get("/me", protect, getMyProfile);

// Update Profile
router.put("/update-profile", protect, updateProfile);

// Change Password
router.put("/change-password", protect, changePassword);

module.exports = router;
/**
 * routes/authRoutes.js
 */


import express from "express";


import {

    registerUser,

    loginUser,

    getProfile

} from "../controllers/authController.js";


import protect from "../middleware/authMiddleware.js";




const router = express.Router();





// Register

router.post(

    "/register",

    registerUser

);




// Login

router.post(

    "/login",

    loginUser

);




// Profile

router.get(

    "/profile",

    protect,

    getProfile

);





export default router;