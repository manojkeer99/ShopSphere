/**
 * models/User.js
 */

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

/* ==========================
   Address Schema
========================== */

const addressSchema = new mongoose.Schema(
{
    fullName: {
        type: String,
        trim: true
    },

    phone: {
        type: String,
        trim: true
    },

    addressLine1: {
        type: String,
        required: true
    },

    addressLine2: {
        type: String,
        default: ""
    },

    city: {
        type: String,
        required: true
    },

    state: {
        type: String,
        required: true
    },

    country: {
        type: String,
        default: "India"
    },

    pincode: {
        type: String,
        required: true
    },

    isDefault: {
        type: Boolean,
        default: false
    }

},
{ _id: false });

/* ==========================
   User Schema
========================== */

const userSchema = new mongoose.Schema(

{

    name: {
        type: String,
        required: true,
        trim: true,
        minlength: 2,
        maxlength: 100
    },

    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },

    password: {
        type: String,
        required: true,
        minlength: 6,
        select: false
    },

    phone: {
        type: String,
        default: ""
    },

    avatar: {
        public_id: String,
        url: String
    },

    role: {
        type: String,
        enum: ["user", "admin"],
        default: "user"
    },

    addresses: [addressSchema],

    wishlist: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Product"
        }
    ],

    isVerified: {
        type: Boolean,
        default: false
    },

    isBlocked: {
        type: Boolean,
        default: false
    },

    lastLogin: {
        type: Date
    
},
resetPasswordToken: {
    type: String,
    default: null
},

resetPasswordExpire: {
    type: Date,
    default: null
},

emailVerificationToken: {
    type: String,
    default: null
},

emailVerificationExpire: {
    type: Date,
    default: null
},

    timestamps: true
});

/* ==========================
   Hash Password
========================== */

userSchema.pre("save", async function(next){

    if(!this.isModified("password"))
        return next();

    const salt = await bcrypt.genSalt(10);

    this.password = await bcrypt.hash(this.password,salt);

    next();

});

/* ==========================
   Compare Password
========================== */

userSchema.methods.comparePassword = async function(password){

    return await bcrypt.compare(password,this.password);

};

/* ==========================
   Generate JWT
========================== */

userSchema.methods.generateToken = function(){

    return jwt.sign(

        {
            id:this._id,
            role:this.role
        },

        process.env.JWT_SECRET,

        {
            expiresIn:process.env.JWT_EXPIRE || "7d"
        }

    );

};

/* ==========================
   Remove Sensitive Data
========================== */

userSchema.methods.toJSON = function(){

    const obj = this.toObject();

    delete obj.password;

    return obj;

};

const crypto = require("crypto");

/* ==========================================
   Generate Password Reset Token
========================================== */

userSchema.methods.getResetPasswordToken = function () {

    const resetToken = crypto
        .randomBytes(32)
        .toString("hex");

    this.resetPasswordToken = crypto
        .createHash("sha256")
        .update(resetToken)
        .digest("hex");

    this.resetPasswordExpire =
        Date.now() + 15 * 60 * 1000;

    return resetToken;
};

/* ==========================================
   Generate Email Verification Token
========================================== */

userSchema.methods.getEmailVerificationToken = function () {

    const token = crypto
        .randomBytes(32)
        .toString("hex");

    this.emailVerificationToken = crypto
        .createHash("sha256")
        .update(token)
        .digest("hex");

    this.emailVerificationExpire =
        Date.now() + 24 * 60 * 60 * 1000;

    return token;
};