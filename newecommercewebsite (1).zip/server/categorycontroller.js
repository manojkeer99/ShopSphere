/**
 * controllers/categoryController.js
 */

const Category = require("../models/Category");
const Product = require("../models/Product");
const asyncHandler = require("../middleware/asyncHandler");


/* =====================================================
   Create Category (Admin)
===================================================== */

exports.createCategory = asyncHandler(async (req,res)=>{

    const {
        name,
        description,
        image
    } = req.body;


    if(!name){

        return res.status(400).json({

            success:false,

            message:"Category name is required."

        });

    }


    const existingCategory =
        await Category.findOne({
            name:name.toLowerCase()
        });


    if(existingCategory){

        return res.status(400).json({

            success:false,

            message:"Category already exists."

        });

    }


    const category =
        await Category.create({

            name,

            description,

            image,

            createdBy:req.user._id

        });


    res.status(201).json({

        success:true,

        message:"Category created successfully.",

        category

    });


});



/* =====================================================
   Get All Categories
===================================================== */

exports.getAllCategories = asyncHandler(async(req,res)=>{


    const categories =
        await Category.find({
            isDeleted:false
        })
        .sort("-createdAt");


    res.status(200).json({

        success:true,

        count:categories.length,

        categories

    });


});



/* =====================================================
   Get Category By ID
===================================================== */

exports.getCategoryById = asyncHandler(async(req,res)=>{


    const category =
        await Category.findById(
            req.params.id
        );


    if(!category){

        return res.status(404).json({

            success:false,

            message:"Category not found."

        });

    }


    res.status(200).json({

        success:true,

        category

    });


});



/* =====================================================
   Update Category (Admin)
===================================================== */

exports.updateCategory = asyncHandler(async(req,res)=>{


    const category =
        await Category.findById(
            req.params.id
        );


    if(!category){

        return res.status(404).json({

            success:false,

            message:"Category not found."

        });

    }


    const {
        name,
        description,
        image,
        status
    } = req.body;


    if(name)
        category.name=name;


    if(description)
        category.description=description;


    if(image)
        category.image=image;


    if(status)
        category.status=status;


    category.updatedBy=req.user._id;


    await category.save();



    res.status(200).json({

        success:true,

        message:"Category updated successfully.",

        category

    });


});



/* =====================================================
   Delete Category (Soft Delete)
===================================================== */

exports.deleteCategory = asyncHandler(async(req,res)=>{


    const category =
        await Category.findById(
            req.params.id
        );


    if(!category){

        return res.status(404).json({

            success:false,

            message:"Category not found."

        });

    }


    category.isDeleted=true;

    category.status="inactive";

    category.updatedBy=req.user._id;


    await category.save();


    res.status(200).json({

        success:true,

        message:"Category deleted successfully."

    });


});
/* =====================================================
   Get Category Product Count
===================================================== */

exports.getCategoryProductCount = asyncHandler(async(req,res)=>{

    const { id } = req.params;


    const category =
        await Category.findById(id);


    if(!category){

        return res.status(404).json({

            success:false,

            message:"Category not found."

        });

    }


    const productCount =
        await Product.countDocuments({

            category:id,

            isDeleted:false,

            status:"active"

        });


    res.status(200).json({

        success:true,

        category:category.name,

        productCount

    });


});



/* =====================================================
   Popular Categories
===================================================== */

exports.getPopularCategories = asyncHandler(async(req,res)=>{


    const categories =
        await Category.aggregate([

            {
                $lookup:{

                    from:"products",

                    localField:"_id",

                    foreignField:"category",

                    as:"products"

                }

            },

            {
                $project:{

                    name:1,

                    image:1,

                    productCount:{
                        $size:"$products"
                    }

                }

            },

            {
                $sort:{
                    productCount:-1
                }
            },

            {
                $limit:10
            }

        ]);



    res.status(200).json({

        success:true,

        categories

    });


});



/* =====================================================
   Search Category
===================================================== */

exports.searchCategory = asyncHandler(async(req,res)=>{


    const keyword =
        req.query.keyword || "";



    const categories =
        await Category.find({

            name:{

                $regex:keyword,

                $options:"i"

            },

            isDeleted:false

        });



    res.status(200).json({

        success:true,

        count:categories.length,

        categories

    });


});