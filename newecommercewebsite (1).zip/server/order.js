const mongoose = require("mongoose");

/* ==========================================================
   SHIPPING ADDRESS
========================================================== */

const shippingAddressSchema = new mongoose.Schema(
{
    fullName: {
        type: String,
        required: true,
        trim: true
    },

    phone: {
        type: String,
        required: true
    },

    addressLine1: {
        type: String,
        required: true
    },

    addressLine2: {
        type: String,
        default: ""
    },

    city: {
        type: String,
        required: true
    },

    state: {
        type: String,
        required: true
    },

    country: {
        type: String,
        default: "India"
    },

    pincode: {
        type: String,
        required: true
    }

},
{
    _id: false
});

/* ==========================================================
   PAYMENT INFORMATION
========================================================== */

const paymentSchema = new mongoose.Schema(
{

    method: {
        type: String,
        enum: [
            "COD",
            "Razorpay",
            "Stripe",
            "UPI"
        ],
        required: true
    },

    paymentStatus: {
        type: String,
        enum: [
            "Pending",
            "Paid",
            "Failed",
            "Refunded"
        ],
        default: "Pending"
    },

    transactionId: String,

    paymentId: String,

    orderId: String

},
{
    _id: false
});

/* ==========================================================
   ORDER ITEM
========================================================== */

const orderItemSchema = new mongoose.Schema(
{

    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Product",
        required: true
    },

    name: {
        type: String,
        required: true
    },

    image: {
        type: String,
        default: ""
    },

    sku: {
        type: String
    },

    quantity: {
        type: Number,
        required: true,
        min: 1
    },

    price: {
        type: Number,
        required: true
    },

    total: {
        type: Number,
        required: true
    }

},
{
    _id: false
});

/* ==========================================================
   ORDER SCHEMA
========================================================== */

const orderSchema = new mongoose.Schema(
{

    orderNumber: {
        type: String,
        unique: true
    },

    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    },

    items: [orderItemSchema],

    shippingAddress: shippingAddressSchema,

    payment: paymentSchema,

    itemTotal: {
        type: Number,
        default: 0
    },

    tax: {
        type: Number,
        default: 0
    },

    shippingCharge: {
        type: Number,
        default: 0
    },

    discount: {
        type: Number,
        default: 0
    },

    grandTotal: {
        type: Number,
        required: true
    },

    couponCode: {
        type: String,
        default: ""
    },

    orderStatus: {
        type: String,
        enum: [
            "Pending",
            "Confirmed",
            "Packed",
            "Shipped",
            "Out For Delivery",
            "Delivered",
            "Cancelled",
            "Returned"
        ],
        default: "Pending"
    },    trackingNumber: {
        type: String,
        default: ""
    },

    courierPartner: {
        type: String,
        default: ""
    },

    estimatedDelivery: {
        type: Date
    },

    deliveredAt: {
        type: Date
    },

    invoiceNumber: {
        type: String,
        unique: true,
        sparse: true
    },

    refundStatus: {
        type: String,
        enum: [
            "None",
            "Requested",
            "Approved",
            "Rejected",
            "Processed"
        ],
        default: "None"
    },

    returnReason: {
        type: String,
        default: ""
    },

    notes: {
        type: String,
        default: ""
    }

},
{
    timestamps: true
});

/* ==========================================================
   TIMELINE SCHEMA
========================================================== */

const timelineSchema = new mongoose.Schema(
{
    status: String,
    message: String,
    updatedAt: {
        type: Date,
        default: Date.now
    }
},
{
    _id: false
});

orderSchema.add({
    timeline: [timelineSchema]
});

/* ==========================================================
   INDEXES
========================================================== */

orderSchema.index({ orderNumber: 1 });
orderSchema.index({ user: 1 });
orderSchema.index({ orderStatus: 1 });
orderSchema.index({ createdAt: -1 });

/* ==========================================================
   PRE SAVE
========================================================== */

orderSchema.pre("save", function(next) {

    if (!this.orderNumber) {
        this.orderNumber =
            "ORD-" +
            Date.now() +
            "-" +
            Math.floor(Math.random() * 1000);
    }

    if (!this.invoiceNumber) {
        this.invoiceNumber =
            "INV-" +
            Date.now() +
            "-" +
            Math.floor(Math.random() * 1000);
    }

    next();
});

/* ==========================================================
   METHODS
========================================================== */

orderSchema.methods.calculateTotal = function () {

    const itemsTotal = this.items.reduce(
        (sum, item) => sum + item.total,
        0
    );

    this.itemTotal = itemsTotal;

    this.grandTotal =
        itemsTotal +
        this.tax +
        this.shippingCharge -
        this.discount;

    return this.grandTotal;
};

orderSchema.methods.addTimeline = function(status, message) {

    this.timeline.push({
        status,
        message
    });

    return this.save();
};

/* ==========================================================
   EXPORT
========================================================== */

module.exports = mongoose.model(
    "Order",
    orderSchema
);
/**
 * models/Order.js
 */

const mongoose = require("mongoose");



/* ==========================================
   Order Item Schema
========================================== */

const orderItemSchema = new mongoose.Schema({

    product: {

        type: mongoose.Schema.Types.ObjectId,

        ref: "Product",

        required:true

    },


    name: {

        type:String,

        required:true

    },


    image: {

        type:String

    },


    quantity: {

        type:Number,

        required:true

    },


    price: {

        type:Number,

        required:true

    },


    total: {

        type:Number,

        required:true

    }


},{

    _id:false

});



/* ==========================================
   Shipping Address Schema
========================================== */

const shippingAddressSchema =
new mongoose.Schema({

    fullName:{

        type:String,

        required:true

    },


    phone:{

        type:String,

        required:true

    },


    address:{

        type:String,

        required:true

    },


    city:{

        type:String,

        required:true

    },


    state:{

        type:String,

        required:true

    },


    postalCode:{

        type:String,

        required:true

    }


},{

    _id:false

});



/* ==========================================
   Order Schema
========================================== */

const orderSchema =
new mongoose.Schema({

    user:{

        type:mongoose.Schema.Types.ObjectId,

        ref:"User",

        required:true

    },


    items:[orderItemSchema],



    shippingAddress:
        shippingAddressSchema,



    paymentMethod:{

        type:String,

        enum:[

            "COD",

            "ONLINE"

        ],

        default:"COD"

    },



    paymentStatus:{

        type:String,

        enum:[

            "pending",

            "paid",

            "failed",

            "refunded"

        ],

        default:"pending"

    },



    orderStatus:{

        type:String,

        enum:[

            "placed",

            "confirmed",

            "processing",

            "shipped",

            "delivered",

            "cancelled"

        ],

        default:"placed"

    },



    subtotal:{

        type:Number,

        required:true

    },


    shippingCharge:{

        type:Number,

        default:0

    },


    discount:{

        type:Number,

        default:0

    },


    totalAmount:{

        type:Number,

        required:true

    },


    transactionId:{

        type:String

    },


    deliveredAt:{

        type:Date

    }


},{

    timestamps:true

});



module.exports =
mongoose.model(
    "Order",
    orderSchema
);