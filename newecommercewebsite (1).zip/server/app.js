/**
 * app.js
 * Main Express Application
 */

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");

const app = express();

/* ===========================
   Basic Configuration
=========================== */

app.set("trust proxy", 1);

/* ===========================
   Security Middleware
=========================== */

app.use(
  helmet({
    crossOriginResourcePolicy: false,
  })
);

/* ===========================
   CORS
=========================== */

app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    credentials: true,
  })
);

/* ===========================
   Body Parser
=========================== */

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

/* ===========================
   Cookie Parser
=========================== */

app.use(cookieParser());

/* ===========================
   Logger
=========================== */

app.use(morgan("dev"));

/* ===========================
   Health Check
=========================== */

app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "E-Commerce API Running Successfully",
    version: "1.0.0",
  });
});

/* ===========================
   API Routes
=========================== */

// Authentication
app.use("/api/auth", require("./routes/authRoutes"));

// Products
app.use("/api/products", require("./routes/productRoutes"));

// Categories
app.use("/api/categories", require("./routes/categoryRoutes"));

// Cart
app.use("/api/cart", require("./routes/cartRoutes"));

// Orders
app.use("/api/orders", require("./routes/orderRoutes"));

// Users
app.use("/api/users", require("./routes/userRoutes"));

// Reviews
app.use("/api/reviews", require("./routes/reviewRoutes"));

// Admin
app.use("/api/admin", require("./routes/adminRoutes"));

/* ===========================
   404 Route
=========================== */

app.use("*", (req, res) => {
  res.status(404).json({
    success: false,
    message: "Route Not Found",
  });
});

/* ===========================
   Global Error Handler
=========================== */

app.use((err, req, res, next) => {
  console.error("ERROR:", err);

  res.status(err.statusCode || 500).json({
    success: false,
    message: err.message || "Internal Server Error",
  });
});

module.exports = app;
const errorHandler = require("./middleware/errorHandler");

// Keep this as the last middleware
app.use(errorHandler);
const authRoutes = require("./routes/authRoutes");

app.use("/api/auth", authRoutes);
const productRoutes = require("./routes/productRoutes");

app.use(
    "/api/products",
    productRoutes
);
const categoryRoutes = require("./routes/categoryRoutes");

app.use(
    "/api/categories",
    categoryRoutes
);
const orderRoutes = require("./routes/orderRoutes");

app.use(
    "/api/orders",
    orderRoutes
);
const paymentRoutes = require("./routes/paymentRoutes");

app.use(
    "/api/payment",
    paymentRoutes
);