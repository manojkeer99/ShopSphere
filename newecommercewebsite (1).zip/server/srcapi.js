/**
 * api/api.js
 */


import axios from "axios";



const api = axios.create({


    baseURL:

    import.meta.env.VITE_API_URL || 
    "http://localhost:5000/api",



    headers:{


        "Content-Type":

        "application/json"


    }


});





// Request Interceptor
// Attach JWT Token automatically

api.interceptors.request.use(

    (config)=>{


        const token =

        localStorage.getItem("token");



        if(token){


            config.headers.Authorization =

            `Bearer ${token}`;


        }



        return config;


    },


    (error)=>{


        return Promise.reject(error);


    }

);





// Response Interceptor

api.interceptors.response.use(


    (response)=>{


        return response;


    },


    (error)=>{


        if(error.response?.status === 401){


            localStorage.removeItem("token");


        }



        return Promise.reject(error);


    }


);



export default api;