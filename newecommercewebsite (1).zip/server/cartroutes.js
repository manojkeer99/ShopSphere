/**
 * routes/cartRoutes.js
 */

const express = require("express");

const router = express.Router();


const {
    getMyCart,
    addToCart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    applyCoupon,
    removeCoupon

} = require("../controllers/cartController");


const {
    protect

} = require("../middleware/authMiddleware");



/* =====================================================
   Cart Routes
===================================================== */


// Get My Cart
router.get(
    "/",
    protect,
    getMyCart
);


// Add Product
router.post(
    "/add",
    protect,
    addToCart
);


// Update Quantity
router.put(
    "/update",
    protect,
    updateCartQuantity
);


// Remove Product
router.delete(
    "/remove/:productId",
    protect,
    removeFromCart
);


// Clear Cart
router.delete(
    "/clear",
    protect,
    clearCart
);


// Apply Coupon
router.post(
    "/apply-coupon",
    protect,
    applyCoupon
);


// Remove Coupon
router.delete(
    "/remove-coupon",
    protect,
    removeCoupon
);



module.exports = router;
/**
 * routes/cartRoutes.js
 */


import express from "express";


import {

    getCart,

    addToCart,

    removeFromCart,

    updateQuantity

} from "../controllers/cartController.js";


import protect from "../middleware/authMiddleware.js";



const router = express.Router();





// Get Cart

router.get(

    "/",

    protect,

    getCart

);





// Add Product

router.post(

    "/add",

    protect,

    addToCart

);





// Update Quantity

router.put(

    "/update/:productId",

    protect,

    updateQuantity

);





// Remove Product

router.delete(

    "/remove/:productId",

    protect,

    removeFromCart

);





export default router;