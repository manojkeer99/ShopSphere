/**
 * pages/Checkout.jsx
 */

import {
    useState
} from "react";


import {
    useDispatch,
    useSelector
} from "react-redux";


import {
    createOrder
} from "../features/orders/orderSlice";


import {
    useNavigate
} from "react-router-dom";


import toast from "react-hot-toast";


import "./Checkout.css";



function Checkout(){


    const dispatch = useDispatch();

    const navigate = useNavigate();



    const {

        grandTotal

    } = useSelector(

        state=>state.cart

    );



    const [address,setAddress]=useState({

        fullName:"",

        phone:"",

        address:"",

        city:"",

        state:"",

        postalCode:""

    });



    const [paymentMethod,setPaymentMethod]=useState(
        "COD"
    );




    const handleChange=(e)=>{


        setAddress({

            ...address,

            [e.target.name]:
            e.target.value

        });


    };




    const handleSubmit=(e)=>{


        e.preventDefault();



        dispatch(

            createOrder({

                shippingAddress:address,

                paymentMethod,

                amount:grandTotal

            })

        )

        .unwrap()

        .then(()=>{


            toast.success(

                "Order placed successfully"

            );


            navigate("/");


        })

        .catch((err)=>{


            toast.error(

                err || "Order failed"

            );


        });


    };





    return (

        <div className="checkout-page">


            <h1>

                Checkout

            </h1>



            <form

            onSubmit={handleSubmit}

            >


                <input

                name="fullName"

                placeholder="Full Name"

                onChange={handleChange}

                required

                />


                <input

                name="phone"

                placeholder="Phone Number"

                onChange={handleChange}

                required

                />


                <textarea

                name="address"

                placeholder="Address"

                onChange={handleChange}

                required

                />



                <input

                name="city"

                placeholder="City"

                onChange={handleChange}

                required

                />


                <input

                name="state"

                placeholder="State"

                onChange={handleChange}

                required

                />



                <input

                name="postalCode"

                placeholder="Postal Code"

                onChange={handleChange}

                required

                />



                <select

                value={paymentMethod}

                onChange={
                    e=>setPaymentMethod(
                        e.target.value
                    )
                }

                >


                    <option value="COD">

                        Cash On Delivery

                    </option>


                    <option value="ONLINE">

                        Online Payment

                    </option>


                </select>




                <button>

                    Place Order

                </button>


            </form>


        </div>

    );

}


export default Checkout;