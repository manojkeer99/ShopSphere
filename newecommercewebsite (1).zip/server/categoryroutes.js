/**
 * routes/categoryRoutes.js
 */

const express = require("express");

const router = express.Router();


const {

    createCategory,
    getAllCategories,
    getCategoryById,
    updateCategory,
    deleteCategory,
    getCategoryProductCount,
    getPopularCategories,
    searchCategory

} = require("../controllers/categoryController");


const {
    protect,
    admin
} = require("../middleware/authMiddleware");



/* =====================================================
   Public Routes
===================================================== */

// Get All Categories
router.get(
    "/",
    getAllCategories
);


// Get Category By ID
router.get(
    "/:id",
    getCategoryById
);


// Popular Categories
router.get(
    "/popular/list",
    getPopularCategories
);


// Search Categories
router.get(
    "/search/query",
    searchCategory
);


// Product Count By Category
router.get(
    "/:id/products-count",
    getCategoryProductCount
);



/* =====================================================
   Admin Routes
===================================================== */


// Create Category
router.post(
    "/admin/create",
    protect,
    admin,
    createCategory
);


// Update Category
router.put(
    "/admin/:id",
    protect,
    admin,
    updateCategory
);


// Delete Category
router.delete(
    "/admin/:id",
    protect,
    admin,
    deleteCategory
);



module.exports = router;