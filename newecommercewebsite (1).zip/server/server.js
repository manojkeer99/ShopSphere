
/**
 * server.js
 */
import userRoutes from "./routes/userRoutes.js";
import orderRoutes from "./routes/orderRoutes.js";
import express from "express";

import dotenv from "dotenv";

import cors from "cors";
import adminRoutes from "./routes/adminRoutes.js";
import connectDB from "./config/db.js";
import paymentRoutes from "./routes/paymentRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import productRoutes from "./routes/productRoutes.js";
import cartRoutes from "./routes/cartRoutes.js";
import wishlistRoutes from "./routes/wishlistRoutes.js";

dotenv.config();



connectDB();



const app = express();



// Middleware
app.use(

    "/api/products",

    productRoutes

);
app.use(

    "/api/payment",

    paymentRoutes

);
app.use(

    "/api/wishlist",

    wishlistRoutes

);
app.use(

    "/api/users",

    userRoutes

);app.use(

    "/api/admin",

    adminRoutes

);
app.use(

    "/api/orders",

    orderRoutes

);
app.use(

    "/api/cart",

    cartRoutes

);
app.use(

    cors()

);
app.use(

    "/api/auth",

    authRoutes

);


app.use(

    express.json()

);



// Test Route

app.get(

    "/",

    (req,res)=>{


        res.send(

            "ShopSphere API Running 🚀"

        );


    }

);





const PORT =
process.env.PORT || 5000;



app.listen(

    PORT,

    ()=>{


        console.log(

            `Server running on port ${PORT}`

        );


    }

);
import express from "express";

import dotenv from "dotenv";

import cors from "cors";

import connectDB from "./config/db.js";


import authRoutes from "./routes/authRoutes.js";

import productRoutes from "./routes/productRoutes.js";

import cartRoutes from "./routes/cartRoutes.js";

import wishlistRoutes from "./routes/wishlistRoutes.js";

import orderRoutes from "./routes/orderRoutes.js";

import userRoutes from "./routes/userRoutes.js";

import adminRoutes from "./routes/adminRoutes.js";

import paymentRoutes from "./routes/paymentRoutes.js";

import errorMiddleware from "./middleware/errorMiddleware.js";



dotenv.config();



connectDB();



const app = express();



app.use(cors());


app.use(express.json());





// Routes

app.use("/api/auth", authRoutes);

app.use("/api/products", productRoutes);

app.use("/api/cart", cartRoutes);

app.use("/api/wishlist", wishlistRoutes);

app.use("/api/orders", orderRoutes);

app.use("/api/users", userRoutes);

app.use("/api/admin", adminRoutes);

app.use("/api/payment", paymentRoutes);





app.get("/",(req,res)=>{


    res.send("ShopSphere API Running 🚀");


});





// 404 Handler

app.use((req,res)=>{


    res.status(404).json({

        message:"Route not found"

    });


});





// Error Handler

app.use(errorMiddleware);





const PORT =

process.env.PORT || 5000;



app.listen(PORT,()=>{


    console.log(

        `Server running on ${PORT}`

    );


});
